import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from config import get_config
from DataLoader.exp1_data_loader import Exp1DataLoader
from training.trainer_exp1 import Exp1Trainer
from experiments.demo_experiment1 import run_experiment1

def main():
    """运行实验1"""
    print("=== 开始实验1: 噪声环境鲁棒性验证 ===")
    
    # 获取配置
    config = get_config("experiment1")
    print(f"批次大小: {config.batch_size}")
    print(f"学习率: {config.base_learning_rate}")
    print(f"对比损失权重: {config.contrastive_loss_weight}")
    
    # 运行实验
    run_experiment1(config)

if __name__ == "__main__":
    main()