import torch
import torch.nn as nn
import torch.nn.functional as F

class DynamicSeparableConv(nn.Module):
    def __init__(self, in_channels=1, out_channels=32):
        super().__init__()
        self.depthwise_conv = nn.Conv2d(
            in_channels, in_channels, kernel_size=3, padding=1,
            groups=in_channels, bias=False
        )
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.pointwise_conv = nn.Conv2d(
            in_channels, out_channels, kernel_size=1, bias=False
        )
        self.bn2 = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        if x.numel() == 0:
            return torch.zeros((x.size(0), 32, x.size(2), x.size(3)), device=x.device)

        x = self.depthwise_conv(x)
        x = self.bn1(x)
        x = F.relu(x)
        x = self.pointwise_conv(x)
        x = self.bn2(x)
        x = F.relu(x)
        return x

class MultiScaleTemporalPyramid(nn.Module):
    def __init__(self, in_channels=32, base_channels=32, output_timesteps=32, output_channels=96):
        super().__init__()
        self.output_timesteps = output_timesteps
        self.branch1 = nn.Sequential(
            nn.Conv1d(in_channels, base_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(base_channels),
            nn.ReLU()
        )
        self.branch2 = nn.Sequential(
            nn.Conv1d(in_channels, base_channels, kernel_size=5, padding=2),
            nn.BatchNorm1d(base_channels),
            nn.ReLU()
        )
        self.branch3 = nn.Sequential(
            nn.Conv1d(in_channels, base_channels, kernel_size=7, padding=3),
            nn.BatchNorm1d(base_channels),
            nn.ReLU()
        )
        self.adaptive_pool = nn.AdaptiveAvgPool1d(output_timesteps)
        self.channel_reduction = nn.Sequential(
            nn.Conv1d(base_channels * 3, output_channels, kernel_size=1),
            nn.BatchNorm1d(output_channels),
            nn.ReLU()
        )

    def forward(self, x):
        if x.numel() == 0:
            return torch.zeros((x.size(0), self.channel_reduction[0].out_channels, self.output_timesteps),
                               device=x.device)

        current_timesteps = x.size(2)
        if current_timesteps < 8:
            repeat_factor = (8 + current_timesteps - 1) // current_timesteps
            x = x.repeat(1, 1, repeat_factor)[:, :, :8]

        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        x = torch.cat([b1, b2, b3], dim=1)
        x = self.adaptive_pool(x)
        x = self.channel_reduction(x)
        return x

class SpatioTemporalEncoder(nn.Module):
    def __init__(self, num_channels=1, feature_dim=96):
        super().__init__()
        self.spatial_conv = DynamicSeparableConv(num_channels, 32)
        self.temporal_pyramid = MultiScaleTemporalPyramid(32, 32, 32, feature_dim)
        self.feature_dim = feature_dim

    def forward(self, x):
        batch_size, timesteps, channels, height, width = x.shape

        if batch_size == 0:
            return torch.zeros((0, 32, self.feature_dim), device=x.device)

        x_reshaped = x.reshape(-1, channels, height, width)
        x_conv = self.spatial_conv(x_reshaped)
        x_temporal = x_conv.reshape(batch_size, timesteps, 32, height, width)
        x_temporal = x_temporal.permute(0, 2, 1, 3, 4)

        try:
            x_temporal = x_temporal.reshape(batch_size, 32, timesteps, -1)
        except RuntimeError as e:
            x_temporal = x_temporal.contiguous().view(batch_size, 32, timesteps, -1)

        x_temporal = x_temporal.mean(dim=-1)
        x_pyramid = self.temporal_pyramid(x_temporal)
        x_attention = x_pyramid.transpose(1, 2)
        return x_attention

class EnhancedHybridAttention(nn.Module):
    def __init__(self, dim=96, num_heads=8, dropout=0.1):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads

        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"
        self.head_dim = dim // num_heads

        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 4, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        attn_out, _ = self.multihead_attn(x, x, x)
        x = self.norm1(x + attn_out)
        ffn_out = self.ffn(x)
        x = self.norm2(x + ffn_out)
        return x