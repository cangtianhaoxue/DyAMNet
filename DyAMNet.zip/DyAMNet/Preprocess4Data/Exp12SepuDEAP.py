import scipy.io as sio
import os
import glob
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from scipy.signal import find_peaks, butter, filtfilt
import warnings

warnings.filterwarnings('ignore')

N_MICROSTATES = 4

DATASET_CHANNELS = {
    'N1_EOG': 32,
    'N2_EMG': 32,
    'N3_IDN': 32,
    'N4_EOG_EMG': 32,
    'N5_EOG_EMG_IDN': 32
}

DATASET_SFREQ = {
    'N1_EOG': 128,
    'N2_EMG': 128,
    'N3_IDN': 128,
    'N4_EOG_EMG': 128,
    'N5_EOG_EMG_IDN': 128
}

DATASET_TARGET_LENGTHS = {
    'N1_EOG': 8064,
    'N2_EMG': 8064,
    'N3_IDN': 8064,
    'N4_EOG_EMG': 8064,
    'N5_EOG_EMG_IDN': 8064
}

DATASET_WEIGHTS = {
    'N1_EOG': 100,
    'N2_EMG': 100,
    'N3_IDN': 100,
    'N4_EOG_EMG': 100,
    'N5_EOG_EMG_IDN': 100
}

FREQUENCY_BANDS = {
    'delta': (0.5, 3),
    'theta': (4, 7),
    'alpha': (8, 13)
}

class DataShapeProcessor:
    @staticmethod
    def process_deap_shape(data):
        if data is None:
            return None
        return data.T

class DataLoader:
    def __init__(self):
        self.datasets = {}
        self.shape_processor = DataShapeProcessor()

    def load_deap_data(self, folder_path, dataset_name):
        filenames = []
        data_list = []

        mat_files = glob.glob(os.path.join(folder_path, "*.mat"))

        for mat_file in mat_files:
            try:
                mat_data = sio.loadmat(mat_file)
                filename = os.path.splitext(os.path.basename(mat_file))[0]
                filenames.append(filename)

                if 'eeg_data' in mat_data:
                    eeg_data = mat_data['eeg_data']
                    eeg_reshaped = self.shape_processor.process_deap_shape(eeg_data)
                    data_list.append(eeg_reshaped)
                else:
                    data_list.append(None)

            except Exception as e:
                data_list.append(None)

        return filenames, data_list

    def load_all_datasets(self):
        base_folder = r"D:\pythonProject\EII-DAN\data\DEAP_processed_N"

        dataset_folders = {
            'N1_EOG': os.path.join(base_folder, "N1_EOG"),
            'N2_EMG': os.path.join(base_folder, "N2_EMG"),
            'N3_IDN': os.path.join(base_folder, "N3_IDN"),
            'N4_EOG_EMG': os.path.join(base_folder, "N4_EOG_EMG"),
            'N5_EOG_EMG_IDN': os.path.join(base_folder, "N5_EOG_EMG_IDN")
        }

        for dataset_name, folder_path in dataset_folders.items():
            if os.path.exists(folder_path):
                filenames, data = self.load_deap_data(folder_path, dataset_name)
                self.datasets[dataset_name] = {'filenames': filenames, 'data': data, 'folder_name': dataset_name}
            else:
                self.datasets[dataset_name] = {'filenames': [], 'data': [], 'folder_name': dataset_name}

        self._print_statistics()
        return self.datasets

    def _print_statistics(self):
        for dataset_name, dataset in self.datasets.items():
            valid_count = len([d for d in dataset['data'] if d is not None])
            total_files = len(dataset['filenames'])

class BandProcessor:
    def __init__(self):
        self.bands = FREQUENCY_BANDS

    def bandpass_filter(self, data, low_freq, high_freq, sfreq):
        if data is None:
            return None

        nyquist = sfreq / 2
        low = low_freq / nyquist
        high = high_freq / nyquist

        if low <= 0 or high >= 1:
            return data

        try:
            b, a = butter(4, [low, high], btype='band')
            filtered_data = filtfilt(b, a, data, axis=0)
            return filtered_data
        except Exception as e:
            return data

    def extract_band_data(self, eeg_data, dataset_name, band_name):
        if eeg_data is None:
            return None

        sfreq = DATASET_SFREQ[dataset_name]
        low_freq, high_freq = self.bands[band_name]

        if len(eeg_data.shape) != 2:
            return None

        filtered_data = self.bandpass_filter(eeg_data, low_freq, high_freq, sfreq)
        return filtered_data

    def preprocess_data(self, eeg_data):
        if eeg_data is None:
            return None

        if len(eeg_data.shape) != 2:
            return eeg_data

        scaler = StandardScaler()
        eeg_normalized = scaler.fit_transform(eeg_data)
        return eeg_normalized

class PersonalizedTemplateExtractor:
    def __init__(self, n_states=N_MICROSTATES):
        self.n_states = n_states

    def extract_templates(self, eeg_data, sfreq=128):
        if eeg_data is None:
            return None

        if len(eeg_data.shape) != 2:
            return None

        n_timepoints, n_channels = eeg_data.shape

        if n_timepoints < 100:
            return self._generate_random_templates(eeg_data)

        gfp = self._calculate_gfp(eeg_data)
        peak_indices = self._find_gfp_peaks(gfp, sfreq)

        if len(peak_indices) < self.n_states:
            if n_timepoints < self.n_states:
                peak_indices = np.random.choice(n_timepoints, self.n_states, replace=True)
            else:
                peak_indices = np.random.choice(n_timepoints, self.n_states, replace=False)

        topographies = eeg_data[peak_indices, :]
        actual_n_states = min(self.n_states, len(peak_indices))
        kmeans = KMeans(n_clusters=actual_n_states, random_state=42, n_init=10)
        kmeans.fit(topographies)

        templates = kmeans.cluster_centers_
        return templates

    def _calculate_gfp(self, eeg_data):
        return np.std(eeg_data, axis=1)

    def _find_gfp_peaks(self, gfp, sfreq, min_distance_ms=20):
        min_distance_samples = int(min_distance_ms * sfreq / 1000)
        if min_distance_samples < 1:
            min_distance_samples = 1

        peaks, _ = find_peaks(gfp, distance=min_distance_samples)
        return peaks

    def _generate_random_templates(self, eeg_data):
        n_channels = eeg_data.shape[1]
        mean_val = np.mean(eeg_data, axis=0)
        std_val = np.std(eeg_data, axis=0)

        templates = []
        for i in range(self.n_states):
            template = np.random.normal(mean_val, std_val / 2)
            templates.append(template)

        return np.array(templates)

class CrossDatasetTemplateManager:
    def __init__(self):
        self.dataset_templates = {}

    def add_templates(self, templates, dataset_name, band_name):
        if templates is not None:
            key = f"{dataset_name}_{band_name}"
            if key not in self.dataset_templates:
                self.dataset_templates[key] = []
            self.dataset_templates[key].append(templates)

    def get_compatible_templates(self, target_dataset, target_band):
        target_channels = DATASET_CHANNELS[target_dataset]
        compatible_templates = []

        for key, templates_list in self.dataset_templates.items():
            try:
                parts = key.split('_')
                dataset_part = '_'.join(parts[:-1])
                band_part = parts[-1]

                if band_part == target_band:
                    for templates in templates_list:
                        if templates.shape[1] == target_channels:
                            compatible_templates.append(templates)
            except Exception:
                continue

        return compatible_templates

class BalancedGlobalTemplateLearner:
    def __init__(self, n_states=N_MICROSTATES):
        self.n_states = n_states
        self.global_templates = None
        self.template_manager = CrossDatasetTemplateManager()

    def add_subject_templates(self, templates, dataset_name, band_name):
        self.template_manager.add_templates(templates, dataset_name, band_name)

    def learn_balanced_global_templates(self, target_dataset, target_band):
        compatible_templates = self.template_manager.get_compatible_templates(target_dataset, target_band)

        if not compatible_templates:
            return None

        balanced_templates = self._balanced_sampling_simple(compatible_templates, target_dataset)

        if not balanced_templates:
            return None

        try:
            all_templates_combined = np.vstack(balanced_templates)
        except ValueError:
            return None

        kmeans = KMeans(n_clusters=self.n_states, random_state=42, n_init=10)
        kmeans.fit(all_templates_combined)

        self.global_templates = kmeans.cluster_centers_
        return self.global_templates

    def _balanced_sampling_simple(self, templates_list, target_dataset):
        balanced_templates = []
        target_count = DATASET_WEIGHTS.get(target_dataset, 50)

        if len(templates_list) >= target_count:
            selected_indices = np.random.choice(len(templates_list), target_count, replace=False)
            balanced_templates = [templates_list[i] for i in selected_indices]
        else:
            balanced_templates = templates_list.copy()
            if len(templates_list) < target_count:
                additional_count = target_count - len(templates_list)
                additional_indices = np.random.choice(len(templates_list), additional_count, replace=True)
                balanced_templates.extend([templates_list[i] for i in additional_indices])

        return balanced_templates

class AdaptiveStateRecognizer:
    def __init__(self, templates):
        self.templates = templates
        self.n_states = templates.shape[0]

    def recognize_states(self, eeg_data):
        if eeg_data is None:
            return None

        if len(eeg_data.shape) != 2:
            return None

        n_samples, n_channels = eeg_data.shape

        if n_channels != self.templates.shape[1]:
            return None

        states = np.zeros(n_samples, dtype=int)

        for i in range(n_samples):
            correlations = np.zeros(self.n_states)
            for j in range(self.n_states):
                correlation = np.corrcoef(eeg_data[i, :], self.templates[j, :])[0, 1]
                if np.isnan(correlation):
                    correlations[j] = 0
                else:
                    correlations[j] = correlation
            states[i] = np.argmax(correlations)

        return states

    def optimize_transitions(self, states, window_size=5):
        if states is None or len(states) < window_size:
            return states

        smoothed_states = states.copy()
        half_window = window_size // 2

        for i in range(len(states)):
            start_idx = max(0, i - half_window)
            end_idx = min(len(states), i + half_window + 1)
            window = states[start_idx:end_idx]

            unique_states, counts = np.unique(window, return_counts=True)
            most_frequent_state = unique_states[np.argmax(counts)]

            current_state_count = np.sum(window == states[i])
            if states[i] != most_frequent_state and current_state_count < (window_size // 2):
                smoothed_states[i] = most_frequent_state

        return smoothed_states

class TimeProportionalResampler:
    def resample(self, states, original_length, target_length):
        if states is None:
            return None

        if original_length == target_length or target_length is None:
            return states

        original_time = np.linspace(0, 1, original_length)
        target_time = np.linspace(0, 1, target_length)

        resampled_states = np.zeros(target_length, dtype=int)

        for i, target_t in enumerate(target_time):
            nearest_idx = np.argmin(np.abs(original_time - target_t))
            resampled_states[i] = states[nearest_idx]

        return resampled_states

class BandSpecificMicrostateAnalyzer:
    def __init__(self, band_name):
        self.band_name = band_name
        self.data_loader = DataLoader()
        self.band_processor = BandProcessor()
        self.global_templates_by_dataset = {}

    def execute_stage_one(self, datasets):
        global_learner = BalancedGlobalTemplateLearner()
        template_extractor = PersonalizedTemplateExtractor()

        for dataset_name, dataset in datasets.items():
            filenames = dataset['filenames']
            data_list = dataset['data']
            sfreq = DATASET_SFREQ[dataset_name]

            for i, (filename, eeg_data) in enumerate(zip(filenames, data_list)):
                if eeg_data is None:
                    continue

                band_data = self.band_processor.extract_band_data(eeg_data, dataset_name, self.band_name)
                if band_data is None:
                    continue

                preprocessed_data = self.band_processor.preprocess_data(band_data)
                if preprocessed_data is None:
                    continue

                templates = template_extractor.extract_templates(preprocessed_data, sfreq)

                if templates is not None:
                    global_learner.add_subject_templates(templates, dataset_name, self.band_name)

        for dataset_name in datasets.keys():
            global_templates = global_learner.learn_balanced_global_templates(dataset_name, self.band_name)
            if global_templates is not None:
                self.global_templates_by_dataset[dataset_name] = global_templates
            else:
                for eeg_data in datasets[dataset_name]['data']:
                    if eeg_data is not None:
                        band_data = self.band_processor.extract_band_data(eeg_data, dataset_name, self.band_name)
                        if band_data is not None:
                            preprocessed_data = self.band_processor.preprocess_data(band_data)
                            templates = template_extractor.extract_templates(preprocessed_data, DATASET_SFREQ[dataset_name])
                            if templates is not None:
                                self.global_templates_by_dataset[dataset_name] = templates
                                break

        return self.global_templates_by_dataset

    def execute_stage_two(self, datasets, output_base_dir):
        if not self.global_templates_by_dataset:
            return {}

        resampler = TimeProportionalResampler()
        all_microstates = {}

        for dataset_name, dataset in datasets.items():
            global_templates = self.global_templates_by_dataset.get(dataset_name)
            if global_templates is None:
                continue

            state_recognizer = AdaptiveStateRecognizer(global_templates)
            filenames = dataset['filenames']
            data_list = dataset['data']
            folder_name = dataset['folder_name']
            target_length = DATASET_TARGET_LENGTHS[dataset_name]

            dataset_output_dir = os.path.join(output_base_dir, "DEAP", folder_name)
            os.makedirs(dataset_output_dir, exist_ok=True)

            dataset_results = []

            for i, (filename, eeg_data) in enumerate(zip(filenames, data_list)):
                if eeg_data is None:
                    continue

                band_data = self.band_processor.extract_band_data(eeg_data, dataset_name, self.band_name)
                if band_data is None:
                    continue

                preprocessed_data = self.band_processor.preprocess_data(band_data)
                if preprocessed_data is None:
                    continue

                states = state_recognizer.recognize_states(preprocessed_data)
                if states is None:
                    continue

                smoothed_states = state_recognizer.optimize_transitions(states)
                original_length = len(smoothed_states)
                normalized_states = resampler.resample(smoothed_states, original_length, target_length)

                result = {
                    'filename': filename,
                    'microstates': normalized_states,
                    'original_length': original_length,
                    'normalized_length': len(normalized_states),
                    'channels': DATASET_CHANNELS[dataset_name],
                    'folder_name': folder_name
                }
                dataset_results.append(result)

                output_filename = f"{filename}_{folder_name}_{self.band_name}_microstates.csv"
                output_path = os.path.join(dataset_output_dir, output_filename)

                df = pd.DataFrame({
                    'microstate': normalized_states
                })
                df.to_csv(output_path, index=False)

            all_microstates[dataset_name] = dataset_results

        self._create_summary_file(all_microstates, output_base_dir)
        return all_microstates

    def _create_summary_file(self, all_microstates, output_base_dir):
        summary_data = []

        for dataset_name, results in all_microstates.items():
            for result in results:
                summary_data.append({
                    'dataset': dataset_name,
                    'filename': result['filename'],
                    'folder': result['folder_name'],
                    'band': self.band_name,
                    'channels': result['channels'],
                    'original_length': result['original_length'],
                    'normalized_length': result['normalized_length'],
                    'output_file': f"{result['filename']}_{result['folder_name']}_{self.band_name}_microstates.csv"
                })

        if summary_data:
            summary_df = pd.DataFrame(summary_data)
            summary_path = os.path.join(output_base_dir, f"microstates_summary_{self.band_name}.csv")
            summary_df.to_csv(summary_path, index=False)

class CrossDatasetMicrostateAnalyzer:
    def __init__(self):
        self.data_loader = DataLoader()

    def run_complete_analysis(self, output_base_dir=r"D:\pythonProject\EII-DAN\data\microstate_results"):
        datasets = self.data_loader.load_all_datasets()
        bands = ['delta', 'theta', 'alpha']
        all_results = {}

        for band in bands:
            band_analyzer = BandSpecificMicrostateAnalyzer(band)
            global_templates = band_analyzer.execute_stage_one(datasets)

            if global_templates:
                results = band_analyzer.execute_stage_two(datasets, output_base_dir)
                all_results[band] = results

        total_processed = 0
        for band, results in all_results.items():
            band_count = sum(len(results[dataset]) for dataset in results)
            total_processed += band_count

        return all_results

def main():
    analyzer = CrossDatasetMicrostateAnalyzer()
    results = analyzer.run_complete_analysis()

    if results:
        print("Analysis completed successfully")
    else:
        print("Analysis failed")

if __name__ == "__main__":
    main()