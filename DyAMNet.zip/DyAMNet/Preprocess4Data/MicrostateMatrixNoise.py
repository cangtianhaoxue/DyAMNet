import os
import glob
import numpy as np
import pandas as pd
from collections import defaultdict
import json

class BatchMicrostateProcessor:
    def __init__(self, microstate_dir="microstate_results"):
        self.microstate_dir = microstate_dir
        self.dataset_sfreq = {
            'DEAP': 128,
            'SEED': 200,
            'THU_EP': 250
        }

    def detect_dataset_from_filename(self, filename):
        filename_lower = filename.lower()
        if 'deap' in filename_lower:
            return 'DEAP'
        elif 'seed' in filename_lower:
            return 'SEED'
        elif 'thu' in filename_lower or 'ep' in filename_lower:
            return 'THU_EP'
        else:
            return 'DEAP'

    def load_microstate_sequence(self, filepath):
        try:
            df = pd.read_csv(filepath)
            if 'microstate' in df.columns:
                return df['microstate'].values
            else:
                return df.iloc[:, 0].values
        except Exception as e:
            return None

    def calculate_transition_matrix(self, states, n_states=4):
        transition_counts = np.zeros((n_states, n_states), dtype=int)

        for i in range(len(states) - 1):
            current_state = states[i]
            next_state = states[i + 1]
            if current_state < n_states and next_state < n_states:
                transition_counts[current_state, next_state] += 1

        row_sums = transition_counts.sum(axis=1)
        transition_probs = np.zeros((n_states, n_states))

        for i in range(n_states):
            if row_sums[i] > 0:
                transition_probs[i, :] = transition_counts[i, :] / row_sums[i]

        return transition_probs

    def extract_non_diagonal_elements(self, matrix):
        n = matrix.shape[0]
        non_diag = []

        for i in range(n):
            for j in range(n):
                if i != j:
                    non_diag.append(matrix[i, j])

        return np.array(non_diag)

    def calculate_time_coverage(self, states, n_states=4):
        total_time = len(states)
        coverage = np.zeros(n_states)

        for state in range(n_states):
            coverage[state] = np.sum(states == state) / total_time

        return coverage

    def calculate_mean_duration(self, states, sfreq, n_states=4):
        durations = {state: [] for state in range(n_states)}
        current_state = states[0]
        current_duration = 1

        for i in range(1, len(states)):
            if states[i] == current_state:
                current_duration += 1
            else:
                if current_state < n_states:
                    durations[current_state].append(current_duration)
                current_state = states[i]
                current_duration = 1

        if current_state < n_states:
            durations[current_state].append(current_duration)

        mean_durations = np.zeros(n_states)
        for state in range(n_states):
            if durations[state]:
                mean_durations[state] = (np.mean(durations[state]) / sfreq) * 1000
            else:
                mean_durations[state] = 0

        return mean_durations

    def calculate_frequency(self, states, sfreq, n_states=4):
        total_time_seconds = len(states) / sfreq
        frequencies = np.zeros(n_states)

        for state in range(n_states):
            state_changes = np.diff(states == state, prepend=False)
            occurrence_count = np.sum(state_changes & (states == state))
            frequencies[state] = occurrence_count / total_time_seconds

        return frequencies

    def create_5x5_feature_matrix(self, features_24d):
        if len(features_24d) != 24:
            raise ValueError("Features must be 24-dimensional")

        matrix_5x5 = np.zeros((5, 5))

        idx = 0
        for i in range(5):
            for j in range(5):
                if idx < 24:
                    matrix_5x5[i, j] = features_24d[idx]
                    idx += 1
                else:
                    break

        return matrix_5x5

    def extract_features_for_file(self, filepath):
        states = self.load_microstate_sequence(filepath)
        if states is None:
            return None

        filename = os.path.basename(filepath)
        dataset = self.detect_dataset_from_filename(filename)
        sfreq = self.dataset_sfreq.get(dataset, 128)

        n_states = 4

        transition_matrix = self.calculate_transition_matrix(states, n_states)
        transition_features = self.extract_non_diagonal_elements(transition_matrix)

        coverage_features = self.calculate_time_coverage(states, n_states)

        duration_features = self.calculate_mean_duration(states, sfreq, n_states)

        frequency_features = self.calculate_frequency(states, sfreq, n_states)

        all_features = np.concatenate([
            transition_features,
            coverage_features,
            duration_features,
            frequency_features
        ])

        feature_matrix = self.create_5x5_feature_matrix(all_features)

        return {
            'filename': filename,
            'dataset': dataset,
            'sfreq': sfreq,
            'sequence_length': len(states),
            'features_24d': all_features,
            'feature_matrix_5x5': feature_matrix
        }

    def process_specific_folders(self):
        folder_mappings = [
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N1_EOG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N1_EOG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N2_EMG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N2_EMG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N3_IDN',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N3_IDN_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N4_EOG_EMG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N4_EOG_EMG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N5_EOG_EMG_IDN',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\DEAP\N5_EOG_EMG_IDN_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N1_EOG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N1_EOG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N2_EMG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N2_EMG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N3_IDN',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N3_IDN_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N4_EOG_EMG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N4_EOG_EMG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N5_EOG_EMG_IDN',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\SEED\N5_EOG_EMG_IDN_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N1_EOG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N1_EOG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N2_EMG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N2_EMG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N3_IDN',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N3_IDN_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N4_EOG_EMG',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N4_EOG_EMG_Matrix'
            },
            {
                'input': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N5_EOG_EMG_IDN',
                'output': r'D:\pythonProject\EII-DAN\data\microstate_results\THU-EP\N5_EOG_EMG_IDN_Matrix'
            }
        ]

        total_processed = 0
        summary = []

        for mapping in folder_mappings:
            input_dir = mapping['input']
            output_dir = mapping['output']

            if not os.path.exists(input_dir):
                continue

            os.makedirs(output_dir, exist_ok=True)

            pattern = os.path.join(input_dir, "*.csv")
            csv_files = glob.glob(pattern)

            if not csv_files:
                continue

            folder_processed = 0
            for filepath in csv_files:
                filename = os.path.basename(filepath)

                result = self.extract_features_for_file(filepath)
                if result is None:
                    continue

                output_filename = filename.replace('microstates', 'Matrix')
                output_path = os.path.join(output_dir, output_filename)

                try:
                    df = pd.DataFrame(result['feature_matrix_5x5'])
                    df.to_csv(output_path, index=False, header=False)

                    folder_processed += 1
                    total_processed += 1

                    summary.append({
                        'input_file': filepath,
                        'output_file': output_path,
                        'dataset': result['dataset'],
                        'sequence_length': result['sequence_length']
                    })

                except Exception as e:
                    continue

        if summary:
            summary_df = pd.DataFrame(summary)
            summary_path = r'D:\pythonProject\EII-DAN\data\microstate_results\batch_processing_summary.csv'
            summary_df.to_csv(summary_path, index=False)

        return summary

def main():
    processor = BatchMicrostateProcessor()
    results = processor.process_specific_folders()

    print("Batch processing completed")

if __name__ == "__main__":
    main()