import torch
import sys
import os
import time
import numpy as np

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from DataLoader.exp3_data_loader import Exp3DataLoader
from config import get_config
from config.rtx4080_config import RTX4080Config
from models.eii_dan_model import EII_DAN
from training.trainer_exp3 import Exp3Trainer
from training.memory_monitor import MemoryMonitor
from training.stability_monitor import TrainingStabilityMonitor
from utils.check_environment import check_environment

class LabelRemapper:
    @staticmethod
    def remap_dataset_subject_ids(datasets, all_subject_ids):
        subject_to_new_id = {old_id: new_id for new_id, old_id in enumerate(all_subject_ids)}
        
        remapped_datasets = {}
        for domain_name, dataset in datasets.items():
            for sample in dataset.samples:
                old_subject_id = sample['subject_id']
                if old_subject_id in subject_to_new_id:
                    sample['subject_id'] = subject_to_new_id[old_subject_id]
            remapped_datasets[domain_name] = dataset
            
        return remapped_datasets

    @staticmethod
    def validate_labels(datasets, num_subjects):
        for domain_name, dataset in datasets.items():
            subject_ids = set()
            for i in range(min(100, len(dataset))):
                sample = dataset[i]
                subject_ids.add(sample['subject_id'])
            
            min_id = min(subject_ids)
            max_id = max(subject_ids)
            
            if min_id < 0 or max_id >= num_subjects:
                print(f"Warning: Domain {domain_name} has labels out of range [0, {num_subjects-1}]")
                
        return True

def run_experiment3():
    print("Experiment 3: Incremental User Expansion")
    
    check_environment()
    RTX4080Config.apply_optimizations()
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    memory_monitor = MemoryMonitor()
    memory_monitor.start_monitoring()
    
    stability_monitor = TrainingStabilityMonitor()
    
    config = get_config("experiment3")
    
    data_loader = Exp3DataLoader()
    
    print("Loading domains...")
    domains = data_loader.load_all_domains()
    
    datasets = {name: data for name, (data, _) in domains.items()}
    all_subject_ids = data_loader.get_all_subject_ids(domains)
    num_subjects = len(all_subject_ids)
    
    print(f"Total unique subjects: {num_subjects}")
    
    datasets = LabelRemapper.remap_dataset_subject_ids(datasets, all_subject_ids)
    LabelRemapper.validate_labels(datasets, num_subjects)
    
    dataloaders = data_loader.create_data_loaders(
        {name: dataset for name, dataset in datasets.items()},
        batch_size=config.batch_size
    )
    
    model = EII_DAN(
        num_subjects=num_subjects,
        num_timesteps=config.sequence_length,
        spatial_dim=5,
        num_channels=3,
        feature_dim=config.hidden_dimension,
        num_attention_heads=config.num_attention_heads,
        dropout=config.dropout_rate
    )
    
    print(f"Model created with {num_subjects} subjects")
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    trainer = Exp3Trainer(model, device, config)
    
    print("Starting incremental domain training...")
    
    start_time = time.time()
    
    domain_results = trainer.train_incremental_domains(dataloaders, num_subjects)
    
    end_time = time.time()
    training_time = end_time - start_time
    
    memory_monitor.print_summary()
    memory_monitor.clear_gpu_cache()
    
    print("\n=== Experiment 3 Results ===")
    print(f"Total training time: {training_time:.2f} seconds")
    
    for domain_name, accuracy in domain_results.items():
        print(f"{domain_name}: {accuracy:.2f}%")
    
    print("\nIncremental learning progression:")
    source_acc = domain_results.get('source', 0)
    print(f"Source domain (1 subject): {source_acc:.2f}%")
    
    for i in range(1, 8):
        domain_name = f'target_{i}'
        if domain_name in domain_results:
            acc = domain_results[domain_name]
            improvement = acc - source_acc
            print(f"Target domain {i} ({i+1} subjects): {acc:.2f}% (Δ{improvement:+.2f}%)")
    
    print("Experiment 3 completed!")

if __name__ == "__main__":
    start_time = time.time()
    run_experiment3()
    end_time = time.time()
    print(f"Total execution time: {end_time - start_time:.2f} seconds")