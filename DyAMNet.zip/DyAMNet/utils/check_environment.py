# utils/check_environment.py
import torch
import sys
import numpy as np
import pandas as pd

def check_environment():
    """检查运行环境"""
    print("=" * 50)
    print("环境检查")
    print("=" * 50)
    
    # Python版本
    print(f"Python版本: {sys.version}")
    
    # PyTorch信息
    print(f"PyTorch版本: {torch.__version__}")
    print(f"CUDA可用: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"CUDA版本: {torch.version.cuda}")
        print(f"GPU设备: {torch.cuda.get_device_name(0)}")
        print(f"GPU数量: {torch.cuda.device_count()}")
        print(f"GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    
    # 其他关键包
    print(f"NumPy版本: {np.__version__}")
    print(f"Pandas版本: {pd.__version__}")
    
    print("=" * 50)

if __name__ == "__main__":
    check_environment()