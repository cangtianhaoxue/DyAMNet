import os
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import scipy.io as sio
from typing import List, Dict, Optional

class Exp1MicrostateDataset(Dataset):
    def __init__(self, file_paths: List[str], config, subject_id: Optional[int] = None):
        self.file_paths = file_paths
        self.config = config
        self.subject_id = subject_id
        self.data_cache = {}

    def __len__(self) -> int:
        return len(self.file_paths)

    def _load_single_mat_file(self, file_path: str) -> torch.Tensor:
        if file_path in self.data_cache:
            return self.data_cache[file_path]

        try:
            mat_data = sio.loadmat(file_path)

            data_keys = ['microstate_matrix', 'feature_matrix', 'data', 'features', 'matrix']
            data = None
            for key in data_keys:
                if key in mat_data:
                    data = mat_data[key]
                    break

            if data is None:
                for key, value in mat_data.items():
                    if not key.startswith('__') and isinstance(value, np.ndarray):
                        data = value
                        break

            if data is None:
                default = torch.zeros(3, 5, 5)
                self.data_cache[file_path] = default
                return default

            data_tensor = torch.from_numpy(data).float()

            if data_tensor.numel() == 75:
                data_tensor = data_tensor.reshape(3, 5, 5)
            else:
                if data_tensor.numel() >= 75:
                    data_tensor = data_tensor.flatten()[:75].reshape(3, 5, 5)
                else:
                    data_tensor = torch.nn.functional.pad(
                        data_tensor.flatten(), (0, 75 - data_tensor.numel()),
                        mode='constant'
                    ).reshape(3, 5, 5)

            eps = 1e-8
            mean = data_tensor.mean()
            std = data_tensor.std()
            data_tensor = (data_tensor - mean) / (std + eps)
            data_tensor = torch.clamp(data_tensor, min=-3.0, max=3.0)

            self.data_cache[file_path] = data_tensor
            return data_tensor

        except Exception as e:
            default = torch.zeros(3, 5, 5)
            self.data_cache[file_path] = default
            return default

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        file_path = self.file_paths[idx]

        try:
            file_name = os.path.basename(file_path)
            if '_subj' in file_name:
                subj_id = int(file_name.split('_subj')[1].split('_')[0])
            elif 'subj' in file_name:
                subj_id = int(file_name.split('subj')[1].split('_')[0])
            else:
                subj_id = self.subject_id if self.subject_id is not None else 0
        except:
            subj_id = self.subject_id if self.subject_id is not None else 0

        microstate_data = self._load_single_mat_file(file_path)

        if self.config.sequence_length > 1:
            all_frames = [microstate_data] * self.config.sequence_length
            microstate_seq = torch.stack(all_frames[:self.config.sequence_length], dim=0)
        else:
            microstate_seq = microstate_data.unsqueeze(0)

        return {
            'microstate_data': microstate_seq,
            'subject_label': torch.tensor(subj_id, dtype=torch.long),
            'file_path': file_path
        }

class Exp1DataLoader:
    def __init__(self, config):
        self.config = config

    def load_data(self, source_files: List[str], target_files: Dict[str, List[str]]):
        source_dataset = Exp1MicrostateDataset(source_files, self.config)
        
        target_datasets = {}
        for domain_name, files in target_files.items():
            target_datasets[domain_name] = Exp1MicrostateDataset(files, self.config)

        return source_dataset, target_datasets

    def create_data_loaders(self, source_dataset, target_datasets):
        dataloaders = {}

        source_loader = DataLoader(
            source_dataset,
            batch_size=self.config.batch_size,
            shuffle=True,
            num_workers=self.config.num_workers,
            pin_memory=self.config.pin_memory,
            drop_last=True
        )

        dataloaders['source_train'] = source_loader

        for domain_name, target_dataset in target_datasets.items():
            target_loader = DataLoader(
                target_dataset,
                batch_size=self.config.batch_size,
                shuffle=True,
                num_workers=self.config.num_workers,
                pin_memory=self.config.pin_memory,
                drop_last=True
            )
            dataloaders[f'target_{domain_name}_train'] = target_loader

        return dataloaders

def get_subject_files(data_dir: str) -> Dict[int, List[str]]:
    subject_files = {}
    for root, _, files in os.walk(data_dir):
        for file in files:
            if file.endswith('.mat'):
                try:
                    if '_subj' in file:
                        subj_id = int(file.split('_subj')[1].split('_')[0])
                    elif 'subj' in file:
                        subj_id = int(file.split('subj')[1].split('_')[0])
                    else:
                        continue

                    if subj_id not in subject_files:
                        subject_files[subj_id] = []
                    subject_files[subj_id].append(os.path.join(root, file))
                except:
                    continue
    return subject_files