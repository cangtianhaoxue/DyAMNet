import os
import glob
import numpy as np
import scipy.io as sio
import torch
from torch.utils.data import Dataset, DataLoader
from config.rtx4080_config import RTX4080Config


class Exp2MicrostateDataset(Dataset):
    def __init__(self, base_dir, sessions, domain_label):
        self.base_dir = base_dir
        self.sessions = sessions
        self.domain_label = domain_label
        self.samples = self._load_samples()

    def _load_samples(self):
        samples = []

        for session in self.sessions:
            session_folder = os.path.join(self.base_dir, f"Session{session}")
            if not os.path.exists(session_folder):
                continue

            mat_files = glob.glob(os.path.join(session_folder, "*.mat"))

            for mat_file in mat_files:
                filename = os.path.basename(mat_file)
                file_info = self._parse_filename(filename)

                samples.append({
                    'filepath': mat_file,
                    'subject': file_info['subject'],
                    'session': session,
                    'domain': self.domain_label,
                    'movie_id': file_info.get('movie_id', 0),
                    'date': file_info.get('date', 'unknown'),
                    'name': file_info.get('name', 'unknown')
                })

        return samples

    def _parse_filename(self, filename):
        filename = filename.replace('.mat', '')
        parts = filename.split('_')

        info = {
            'dataset': parts[0],
            'subject': 0,
            'date': parts[2] if len(parts) > 2 else 'unknown',
            'name': parts[3] if len(parts) > 3 else 'unknown',
            'movie_id': 0
        }

        if len(parts) > 1:
            try:
                info['subject'] = int(parts[1])
            except ValueError:
                info['subject'] = 0

        if len(parts) > 4:
            try:
                info['movie_id'] = int(parts[4])
            except ValueError:
                info['movie_id'] = 0

        return info

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample_info = self.samples[idx]

        try:
            mat_data = sio.loadmat(sample_info['filepath'])
            feature_matrix = self._extract_feature_matrix(mat_data)

            if feature_matrix is None:
                feature_matrix = np.random.randn(5, 5)

        except Exception as e:
            feature_matrix = np.random.randn(5, 5)

        feature_matrix = self._clean_and_normalize_data(feature_matrix)
        feature_matrix = self._ensure_proper_shape(feature_matrix)

        feature_tensor = torch.FloatTensor(feature_matrix)
        feature_tensor = feature_tensor.unsqueeze(0)
        feature_tensor = feature_tensor.unsqueeze(0)
        feature_tensor = feature_tensor.repeat(1, 128, 1, 1, 1)
        feature_tensor = feature_tensor.squeeze(0)

        return {
            'features': feature_tensor,
            'subject': sample_info['subject'],
            'session': sample_info['session'],
            'domain': sample_info['domain'],
            'movie_id': sample_info['movie_id']
        }

    def _clean_and_normalize_data(self, matrix):
        if np.isnan(matrix).any() or np.isinf(matrix).any():
            matrix = np.nan_to_num(matrix, nan=0.0, posinf=1.0, neginf=-1.0)

        if np.std(matrix) > 0:
            matrix = (matrix - np.mean(matrix)) / (np.std(matrix) + 1e-8)
        else:
            matrix = (matrix - np.mean(matrix)) / 1e-8

        matrix = np.clip(matrix, -10, 10)
        return matrix

    def _extract_feature_matrix(self, mat_data):
        for key in mat_data.keys():
            if 'microstate' in key.lower():
                if isinstance(mat_data[key], np.ndarray) and mat_data[key].ndim >= 2:
                    return mat_data[key]

        for key in mat_data.keys():
            if not key.startswith('__') and isinstance(mat_data[key], np.ndarray):
                if mat_data[key].ndim >= 2:
                    return mat_data[key]

        return None

    def _ensure_proper_shape(self, matrix):
        if matrix is None:
            return np.random.randn(5, 5)

        if matrix.ndim == 1:
            matrix = matrix.reshape(-1, 1)

        if matrix.ndim == 2:
            return self._ensure_2d_shape(matrix, (5, 5))
        elif matrix.ndim == 3:
            if matrix.shape[0] == 1:
                matrix = matrix[0]
            else:
                matrix = np.mean(matrix, axis=0)
            return self._ensure_2d_shape(matrix, (5, 5))
        else:
            return np.random.randn(5, 5)

    def _ensure_2d_shape(self, matrix, target_shape):
        h, w = target_shape
        current_h, current_w = matrix.shape

        if current_h == h and current_w == w:
            return matrix

        if current_h < h or current_w < w:
            padded = np.zeros((h, w))
            actual_h = min(h, current_h)
            actual_w = min(w, current_w)
            padded[:actual_h, :actual_w] = matrix[:actual_h, :actual_w]
            return padded
        else:
            return matrix[:h, :w]


class Exp2DataLoader:
    def __init__(self, base_dir=r"D:\pythonProject\EII-DAN\Exp 2"):
        self.base_dir = base_dir

    def load_data(self, source_sessions=[1, 2], target_sessions=[3]):
        all_subjects = self._get_all_subjects()

        source_dataset = Exp2MicrostateDataset(
            self.base_dir,
            sessions=source_sessions,
            domain_label=0
        )

        target_dataset = Exp2MicrostateDataset(
            self.base_dir,
            sessions=target_sessions,
            domain_label=1
        )

        return source_dataset, target_dataset, all_subjects

    def _get_all_subjects(self):
        subjects = set()

        for session in [1, 2, 3]:
            session_dir = os.path.join(self.base_dir, f"Session{session}")
            if not os.path.exists(session_dir):
                continue

            mat_files = glob.glob(os.path.join(session_dir, "*.mat"))
            for mat_file in mat_files:
                filename = os.path.basename(mat_file)
                file_info = self._parse_filename(filename)
                if file_info['subject'] > 0:
                    subjects.add(file_info['subject'])

        return sorted(list(subjects))

    def _parse_filename(self, filename):
        filename = filename.replace('.mat', '')
        parts = filename.split('_')

        info = {'subject': 0}
        if len(parts) > 1:
            try:
                info['subject'] = int(parts[1])
            except ValueError:
                pass

        return info

    def create_data_loaders(self, source_dataset, target_dataset, batch_size=48):
        source_loader = DataLoader(
            source_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=0,
            pin_memory=RTX4080Config.DATA_LOADING['pin_memory']
        )

        target_loader = DataLoader(
            target_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=RTX4080Config.DATA_LOADING['pin_memory']
        )

        return source_loader, target_loader