import torch
from typing import List, Dict, Any

class TrainingStabilityMonitor:
    def __init__(self):
        self.nan_count = 0
        self.inf_count = 0
        self.gradient_explosion_count = 0
        self.loss_history = []
        self.gradient_norms = []
        self.stability_issues = []

    def check_batch_stability(self, model, loss) -> List[str]:
        issues = []

        if torch.is_tensor(loss):
            if torch.isnan(loss).any():
                self.nan_count += 1
                issues.append("NaN loss")
            if torch.isinf(loss).any():
                self.inf_count += 1
                issues.append("Inf loss")
        else:
            if loss != loss:
                self.nan_count += 1
                issues.append("NaN loss")
            if abs(loss) == float('inf'):
                self.inf_count += 1
                issues.append("Inf loss")

        total_norm = 0.0
        for p in model.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        total_norm = total_norm ** 0.5
        self.gradient_norms.append(total_norm)

        if total_norm > 1000.0:
            self.gradient_explosion_count += 1
            issues.append(f"Gradient explosion (L2 norm: {total_norm:.2f})")

        for name, param in model.named_parameters():
            if torch.isnan(param).any() or torch.isinf(param).any():
                issues.append(f"Parameter anomaly: {name} contains NaN/Inf")

        if not (torch.isnan(loss) or torch.isinf(loss)) and torch.is_tensor(loss):
            self.loss_history.append(loss.item())
        if issues:
            self.stability_issues.extend(issues)

        return issues

    def get_stability_report(self) -> Dict[str, Any]:
        return {
            "nan_count": self.nan_count,
            "inf_count": self.inf_count,
            "gradient_explosion_count": self.gradient_explosion_count,
            "latest_loss": self.loss_history[-1] if self.loss_history else None,
            "max_gradient_norm": max(self.gradient_norms) if self.gradient_norms else 0,
            "recent_issues": self.stability_issues[-5:] if self.stability_issues else []
        }

    def print_epoch_summary(self, epoch: int):
        report = self.get_stability_report()
        print(f"Epoch {epoch} stability summary:")
        print(f"  NaN losses: {report['nan_count']}")
        print(f"  Inf losses: {report['inf_count']}")
        print(f"  Gradient explosions: {report['gradient_explosion_count']}")
        print(f"  Max gradient norm: {report['max_gradient_norm']:.2f}")

    def reset(self):
        self.nan_count = 0
        self.inf_count = 0
        self.gradient_explosion_count = 0
        self.loss_history = []
        self.gradient_norms = []
        self.stability_issues = []