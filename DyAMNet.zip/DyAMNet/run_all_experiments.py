import sys
import os
sys.path.append(os.path.dirname(__file__))

from run_exp1_experiment import main as run_exp1
from run_exp2_experiment import main as run_exp2  
from run_exp3_experiment import main as run_exp3
from run_exp4_experiment import main as run_exp4

def run_all_experiments():
    """运行所有实验"""
    experiments = [
        ("实验1: 噪声环境鲁棒性验证", run_exp1),
        ("实验2: 时间漂移适应", run_exp2),
        ("实验3: 增量用户扩展", run_exp3), 
        ("实验4: 跨场景泛化", run_exp4)
    ]
    
    for exp_name, exp_runner in experiments:
        print(f"\n{'='*50}")
        print(f"开始: {exp_name}")
        print(f"{'='*50}")
        try:
            exp_runner()
            print(f"完成: {exp_name} ✓")
        except Exception as e:
            print(f"错误 in {exp_name}: {e}")
            continue

if __name__ == "__main__":
    run_all_experiments()