import torch
import sys
import os
import time

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from experiments.demo_experiment3 import run_experiment3
from utils.check_environment import check_environment
from config.rtx4080_config import RTX4080Config

def main():
    print("Experiment 3: Incremental User Expansion")
    
    check_environment()
    RTX4080Config.apply_optimizations()
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    start_time = time.time()
    
    try:
        run_experiment3()
        end_time = time.time()
        print(f"Experiment 3 completed! Total time: {end_time - start_time:.2f} seconds")
        
    except Exception as e:
        print(f"Experiment 3 execution failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()