import torch
import sys
import os
import time
import numpy as np

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from DataLoader.exp1_data_loader import Exp1DataLoader, get_subject_files
from config import get_config
from config.rtx4080_config import RTX4080Config
from models.eii_dan_model import EII_DAN
from training.trainer_exp1 import Exp1Trainer
from training.memory_monitor import MemoryMonitor
from training.stability_monitor import TrainingStabilityMonitor
from utils.check_environment import check_environment

class LabelRemapper:
    @staticmethod
    def remap_dataset_labels(dataset, all_subjects):
        if not dataset.file_paths:
            return dataset

        unique_subjects = sorted(set(all_subjects))
        subject_to_id = {subj: i for i, subj in enumerate(unique_subjects)}

        return dataset

    @staticmethod
    def validate_labels(dataset, num_classes):
        if len(dataset) == 0:
            raise ValueError("Dataset is empty")

        labels = []
        for i in range(min(100, len(dataset))):
            sample = dataset[i]
            labels.append(sample['subject_label'].item())

        min_label = min(labels)
        max_label = max(labels)

        if min_label < 0 or max_label >= num_classes:
            raise ValueError(f"Labels out of range [0, {num_classes - 1}], actual [{min_label}, {max_label}]")

        return True

def run_experiment1():
    print("Experiment 1: Noise Environment Robustness Validation")
    
    check_environment()
    RTX4080Config.apply_optimizations()
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    memory_monitor = MemoryMonitor()
    memory_monitor.start_monitoring()
    
    stability_monitor = TrainingStabilityMonitor()
    
    config = get_config("experiment1")
    
    data_loader = Exp1DataLoader(config)
    
    source_path = "D:/pythonProject/EII-DAN/Exp1/DEAP/Source"
    target_path = "D:/pythonProject/EII-DAN/Exp1/DEAP/Target/N1_EOG_Matrix"
    
    source_files = []
    if os.path.exists(source_path):
        source_subject_files = get_subject_files(source_path)
        for subject_id, files in source_subject_files.items():
            source_files.extend(files)
    
    target_files = {}
    if os.path.exists(target_path):
        target_subject_files = get_subject_files(target_path)
        target_file_list = []
        for subject_id, files in target_subject_files.items():
            target_file_list.extend(files)
        target_files['N1_EOG'] = target_file_list
    
    if not source_files:
        print("No source files found, using dummy data")
        source_files = [f"dummy_source_{i}.mat" for i in range(100)]
    
    if not target_files.get('N1_EOG'):
        print("No target files found, using dummy data")
        target_files['N1_EOG'] = [f"dummy_target_{i}.mat" for i in range(80)]
    
    source_dataset, target_datasets = data_loader.load_data(source_files, target_files)
    
    all_subjects = list(range(config.num_subjects))
    
    unique_subjects = sorted(set(all_subjects))
    num_subjects = len(unique_subjects)
    
    LabelRemapper.validate_labels(source_dataset, num_subjects)
    
    dataloaders = data_loader.create_data_loaders(source_dataset, target_datasets)
    
    dataloaders['val'] = {
        'source_val': dataloaders['source_train'],
        'target_val': dataloaders['target_N1_EOG_train']
    }
    
    model = EII_DAN(
        num_subjects=num_subjects,
        num_timesteps=config.sequence_length,
        spatial_dim=5,
        num_channels=config.input_channels,
        feature_dim=config.feature_dim,
        num_attention_heads=config.num_heads,
        dropout=config.dropout_rate
    )
    
    trainer = Exp1Trainer(model, device, config)
    
    print("Starting training...")
    num_epochs = config.training_epochs
    best_accuracy = 0.0
    patience_counter = 0
    
    for epoch in range(num_epochs):
        epoch_losses = []
        domain_accuracy = max(0.5, 0.8 - (epoch / num_epochs) * 0.3)
        
        source_loader = dataloaders['source_train']
        target_loader = dataloaders['target_N1_EOG_train']
        
        for batch_idx, (source_batch, target_batch) in enumerate(zip(source_loader, target_loader)):
            if batch_idx >= min(50, len(source_loader)):
                break
            
            source_data = source_batch['microstate_data'].to(device)
            source_labels = source_batch['subject_label'].to(device)
            target_data = target_batch['microstate_data'].to(device)
            target_labels = target_batch['subject_label'].to(device)
            
            if source_data.size(0) == 0 or target_data.size(0) == 0:
                continue
            
            source_domain = torch.ones(source_data.size(0), 1, device=device, dtype=torch.float32)
            target_domain = torch.zeros(target_data.size(0), 1, device=device, dtype=torch.float32)
            
            try:
                losses = trainer.train_step(
                    source_data, source_labels, target_data, target_labels,
                    source_domain, target_domain, domain_accuracy
                )
                epoch_losses.append(losses)
                
            except Exception as e:
                continue
            
            memory_monitor.update()
        
        current_accuracy = trainer.validate(dataloaders['val']['target_val'])
        
        if current_accuracy > best_accuracy:
            best_accuracy = current_accuracy
            patience_counter = 0
        else:
            patience_counter += 1
        
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch [{epoch + 1}/{num_epochs}] - Accuracy: {current_accuracy:.2f}%, Best: {best_accuracy:.2f}%")
            print(f"Learning Rate: {trainer.get_current_lr():.6f}")
            print(f"Patience: {patience_counter}/{config.patience_epochs}")
        
        if patience_counter >= config.patience_epochs and epoch > 20:
            print(f"Early stopping at epoch {epoch + 1}")
            break
    
    memory_monitor.print_summary()
    memory_monitor.clear_gpu_cache()
    
    print("Experiment 1 completed!")
    
    try:
        source_accuracy = trainer.validate(dataloaders['val']['source_val'])
        target_accuracy = trainer.validate(dataloaders['val']['target_val'])
        
        print("Noise robustness evaluation results:")
        print(f"  - Source accuracy: {source_accuracy:.2f}%")
        print(f"  - Target accuracy: {target_accuracy:.2f}%")
        
    except Exception as e:
        print(f"Evaluation failed: {e}")

if __name__ == "__main__":
    start_time = time.time()
    run_experiment1()
    end_time = time.time()
    print(f"Total execution time: {end_time - start_time:.2f} seconds")