import torch
import sys
import os
import time
import numpy as np

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from DataLoader.exp2_data_loader import Exp2DataLoader
from config import get_config
from config.rtx4080_config import RTX4080Config
from models.eii_dan_model import EII_DAN
from training.trainer_exp2 import Exp2Trainer
from training.memory_monitor import MemoryMonitor
from training.stability_monitor import TrainingStabilityMonitor
from utils.check_environment import check_environment

class LabelRemapper:
    @staticmethod
    def remap_dataset_labels(dataset, all_subjects):
        if not dataset.samples:
            return dataset

        unique_subjects = sorted(set(all_subjects))
        subject_to_id = {subj: i for i, subj in enumerate(unique_subjects)}

        remapped_samples = []
        for sample_info in dataset.samples:
            original_label = sample_info['subject']
            if original_label not in subject_to_id:
                continue

            new_sample_info = sample_info.copy()
            new_sample_info['subject'] = subject_to_id[original_label]
            remapped_samples.append(new_sample_info)

        dataset.samples = remapped_samples
        return dataset

    @staticmethod
    def validate_labels(dataset, num_classes):
        if not dataset.samples:
            raise ValueError("Dataset is empty")

        labels = [sample['subject'] for sample in dataset.samples]
        min_label = min(labels)
        max_label = max(labels)

        if min_label < 0 or max_label >= num_classes:
            raise ValueError(f"Labels out of range [0, {num_classes - 1}], actual [{min_label}, {max_label}]")

        return True

def run_experiment2():
    print("Experiment 2: Temporal Drift Adaptation")
    
    check_environment()
    RTX4080Config.apply_optimizations()
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    memory_monitor = MemoryMonitor()
    memory_monitor.start_monitoring()
    
    stability_monitor = TrainingStabilityMonitor()
    
    config = get_config("experiment2")
    
    data_loader = Exp2DataLoader()
    source_dataset, target_dataset, all_subjects = data_loader.load_data(
        source_sessions=[1, 2],
        target_sessions=[3]
    )
    
    source_dataset = LabelRemapper.remap_dataset_labels(source_dataset, all_subjects)
    target_dataset = LabelRemapper.remap_dataset_labels(target_dataset, all_subjects)
    
    unique_subjects = sorted(set(all_subjects))
    num_subjects = len(unique_subjects)
    
    LabelRemapper.validate_labels(source_dataset, num_subjects)
    LabelRemapper.validate_labels(target_dataset, num_subjects)
    
    source_loader, target_loader = data_loader.create_data_loaders(
        source_dataset, target_dataset, batch_size=config.batch_size
    )
    
    model = EII_DAN(
        num_subjects=num_subjects,
        num_timesteps=config.sequence_length,
        spatial_dim=5,
        num_channels=1,
        feature_dim=config.hidden_dimension,
        num_attention_heads=config.num_attention_heads,
        dropout=config.dropout_rate
    )
    
    trainer = Exp2Trainer(model, device, config)
    
    print("Starting training...")
    num_epochs = config.training_epochs
    best_accuracy = 0.0
    patience_counter = 0
    
    for epoch in range(num_epochs):
        epoch_losses = []
        domain_accuracy = max(0.5, 0.8 - (epoch / num_epochs) * 0.3)
        
        for batch_idx, (source_batch, target_batch) in enumerate(zip(source_loader, target_loader)):
            if batch_idx >= min(50, len(source_loader)):
                break
            
            source_data = source_batch['features'].to(device)
            source_labels = source_batch['subject'].to(device)
            target_data = target_batch['features'].to(device)
            target_labels = target_batch['subject'].to(device)
            
            if source_data.size(0) == 0 or target_data.size(0) == 0:
                continue
            
            source_domain = torch.ones(source_data.size(0), 1, device=device, dtype=torch.float32)
            target_domain = torch.zeros(target_data.size(0), 1, device=device, dtype=torch.float32)
            
            try:
                losses = trainer.train_step(
                    source_data, source_labels, target_data, target_labels,
                    source_domain, target_domain, domain_accuracy
                )
                epoch_losses.append(losses)
                
            except Exception as e:
                continue
            
            memory_monitor.update()
        
        current_accuracy = trainer.validate(source_loader)
        
        if current_accuracy > best_accuracy:
            best_accuracy = current_accuracy
            patience_counter = 0
        else:
            patience_counter += 1
        
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch [{epoch + 1}/{num_epochs}] - Accuracy: {current_accuracy:.2f}%, Best: {best_accuracy:.2f}%")
            print(f"Learning Rate: {trainer.get_current_lr():.6f}")
            print(f"Patience: {patience_counter}/{config.patience_epochs}")
        
        if patience_counter >= config.patience_epochs and epoch > 20:
            print(f"Early stopping at epoch {epoch + 1}")
            break
    
    memory_monitor.print_summary()
    memory_monitor.clear_gpu_cache()
    
    print("Experiment 2 completed!")
    
    try:
        source_accuracy = trainer.validate(source_loader)
        target_accuracy = trainer.validate(target_loader)
        
        print("Cross-session evaluation results:")
        print(f"  - Source accuracy: {source_accuracy:.2f}%")
        print(f"  - Target accuracy: {target_accuracy:.2f}%")
        
    except Exception as e:
        print(f"Evaluation failed: {e}")

if __name__ == "__main__":
    start_time = time.time()
    run_experiment2()
    end_time = time.time()
    print(f"Total execution time: {end_time - start_time:.2f} seconds")