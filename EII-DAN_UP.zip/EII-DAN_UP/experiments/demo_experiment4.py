import torch
import sys
import os
import time
import numpy as np

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from DataLoader.exp4_data_loader import Exp4DataLoader
from config import get_config
from config.rtx4080_config import RTX4080Config
from models.eii_dan_model import EII_DAN
from training.trainer_exp4 import Exp4Trainer
from training.memory_monitor import MemoryMonitor
from training.stability_monitor import TrainingStabilityMonitor
from utils.check_environment import check_environment

def run_experiment4(scheme: int = 1):
    print(f"Experiment 4: Cross-Scenario Generalization - Scheme {scheme}")
    
    check_environment()
    RTX4080Config.apply_optimizations()
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    memory_monitor = MemoryMonitor()
    memory_monitor.start_monitoring()
    
    stability_monitor = TrainingStabilityMonitor()
    
    config = get_config("experiment4")
    
    base_dirs = {
        'DEAP': "D:/pythonProject/EII-DAN/Exp4/DEAP",
        'THU-EP': "D:/pythonProject/EII-DAN/Exp4/THU-EP", 
        'SEED': "D:/pythonProject/EII-DAN/Exp4/SEED"
    }
    
    data_loader = Exp4DataLoader(base_dirs)
    
    if scheme == 1:
        source_datasets, target_datasets = data_loader.create_scheme_1()
    elif scheme == 2:
        source_datasets, target_datasets = data_loader.create_scheme_2()
    elif scheme == 3:
        source_datasets, target_datasets = data_loader.create_scheme_3()
    else:
        raise ValueError(f"Invalid scheme: {scheme}")
    
    all_subject_ids = data_loader.get_all_subject_ids(source_datasets, target_datasets)
    num_subjects = len(all_subject_ids)
    
    print(f"Total unique subjects across all datasets: {num_subjects}")
    
    source_datasets = data_loader.remap_subject_ids(source_datasets, all_subject_ids)
    target_datasets = data_loader.remap_subject_ids(target_datasets, all_subject_ids)
    
    dataloaders = data_loader.create_data_loaders(
        source_datasets, target_datasets, batch_size=config.batch_size
    )
    
    print("DataLoader summary:")
    for name, loader in dataloaders.items():
        print(f"  {name}: {len(loader.dataset)} samples")
    
    model = EII_DAN(
        num_subjects=num_subjects,
        num_timesteps=config.sequence_length,
        spatial_dim=5,
        num_channels=3,
        feature_dim=config.hidden_dimension,
        num_attention_heads=config.num_attention_heads,
        dropout=config.dropout_rate
    )
    
    print(f"Model created with {num_subjects} subjects")
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    trainer = Exp4Trainer(model, device, config)
    
    print("Starting cross-scenario training...")
    
    start_time = time.time()
    
    training_history = trainer.train_cross_scenario(dataloaders)
    
    end_time = time.time()
    training_time = end_time - start_time
    
    print("Starting cross-scenario evaluation...")
    accuracies = trainer.validate_cross_scenario(dataloaders)
    
    memory_monitor.print_summary()
    memory_monitor.clear_gpu_cache()
    
    print(f"\n=== Experiment 4 Results - Scheme {scheme} ===")
    print(f"Total training time: {training_time:.2f} seconds")
    print(f"Final learning rate: {trainer.get_current_lr():.6f}")
    
    print("\nCross-dataset accuracies:")
    source_accuracies = []
    target_accuracies = []
    
    for name, accuracy in accuracies.items():
        if name.startswith('source_'):
            source_accuracies.append(accuracy)
            print(f"  {name}: {accuracy:.2f}%")
        elif name.startswith('target_'):
            target_accuracies.append(accuracy)
            print(f"  {name}: {accuracy:.2f}%")
    
    if source_accuracies:
        avg_source_acc = np.mean(source_accuracies)
        print(f"Average source accuracy: {avg_source_acc:.2f}%")
    
    if target_accuracies:
        avg_target_acc = np.mean(target_accuracies)
        print(f"Average target accuracy: {avg_target_acc:.2f}%")
        
        if source_accuracies:
            generalization_gap = avg_source_acc - avg_target_acc
            print(f"Generalization gap: {generalization_gap:.2f}%")
    
    print(f"\nTraining completed for Scheme {scheme}")
    
    return {
        'scheme': scheme,
        'accuracies': accuracies,
        'training_history': training_history,
        'training_time': training_time
    }

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Run Experiment 4 with specified scheme')
    parser.add_argument('--scheme', type=int, choices=[1, 2, 3], default=1,
                       help='Data scheme to use (1, 2, or 3)')
    
    args = parser.parse_args()
    
    start_time = time.time()
    results = run_experiment4(scheme=args.scheme)
    end_time = time.time()
    
    print(f"Total execution time: {end_time - start_time:.2f} seconds")