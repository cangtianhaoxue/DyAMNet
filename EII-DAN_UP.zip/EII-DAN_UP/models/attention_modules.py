import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class HybridAttention(nn.Module):
    def __init__(self, dim=96, num_heads=4, window_size=32, num_global_tokens=64):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.window_size = window_size
        self.num_global_tokens = num_global_tokens
        self.head_dim = dim // num_heads

        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"

        self.local_qkv = nn.Linear(dim, dim * 3)
        self.global_q = nn.Linear(dim, dim)
        self.global_kv = nn.Linear(dim, dim * 2)
        self.proj = nn.Linear(dim, dim)

        self.importance_net = nn.Sequential(
            nn.Linear(dim, dim // 2),
            nn.ReLU(),
            nn.Linear(dim // 2, 1)
        )

        self.causal_mask = None

    def _create_causal_mask(self, size):
        mask = torch.tril(torch.ones(size, size, device=self.device))
        mask = mask.masked_fill(mask == 0, float('-inf'))
        return mask

    def _local_window_attention(self, x):
        batch_size, num_tokens, _ = x.shape
        self.device = x.device

        adjusted_window_size = min(self.window_size, num_tokens)
        num_windows = max(1, num_tokens // adjusted_window_size)
        adjusted_length = num_windows * adjusted_window_size
        x = x[:, :adjusted_length, :]

        x_windows = x.view(batch_size, num_windows, adjusted_window_size, self.dim)

        qkv = self.local_qkv(x_windows).reshape(
            batch_size, num_windows, adjusted_window_size, 3, self.num_heads, self.head_dim
        ).permute(3, 0, 1, 4, 2, 5)
        q, k, v = qkv[0], qkv[1], qkv[2]

        if self.causal_mask is None or self.causal_mask.shape[0] != adjusted_window_size:
            self.causal_mask = self._create_causal_mask(adjusted_window_size)

        attn = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn = attn + self.causal_mask.unsqueeze(0).unsqueeze(0)
        attn = F.softmax(attn, dim=-1)
        out = (attn @ v).transpose(2, 3).reshape(
            batch_size, num_windows, adjusted_window_size, self.dim
        )
        out = out.reshape(batch_size, -1, self.dim)

        return out

    def _global_sparse_attention(self, local_out, x):
        batch_size, num_tokens, _ = x.shape

        importance_scores = self.importance_net(x).squeeze(-1)
        num_samples = min(self.num_global_tokens, num_tokens)
        _, global_indices = torch.topk(importance_scores, num_samples, dim=-1)

        batch_indices = torch.arange(batch_size, device=x.device).unsqueeze(1).expand(-1, num_samples)
        global_tokens = x[batch_indices, global_indices]

        q = self.global_q(local_out).view(
            batch_size, -1, self.num_heads, self.head_dim
        ).transpose(1, 2)

        kv = self.global_kv(global_tokens).reshape(
            batch_size, -1, 2, self.num_heads, self.head_dim
        ).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        attn = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn = F.softmax(attn, dim=-1)
        out = (attn @ v).transpose(1, 2).reshape(batch_size, -1, self.dim)

        return out

    def forward(self, x):
        local_out = self._local_window_attention(x)
        global_out = self._global_sparse_attention(local_out, x)
        out = local_out + global_out
        out = self.proj(out)
        return out