import torch.nn as nn


class DomainClassifier(nn.Module):
    def __init__(self, input_dim=96, hidden_dim=64):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        if x.dim() == 3:
            x = x.mean(dim=1)
        return self.classifier(x)


class SubjectClassifier(nn.Module):
    def __init__(self, input_dim=96, num_subjects=10):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(input_dim, input_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(input_dim // 2, num_subjects)
        )

    def forward(self, x):
        if x.dim() == 3:
            x = x.mean(dim=1)
        return self.classifier(x)


class ProjectionHead(nn.Module):
    def __init__(self, input_dim=96, output_dim=48):
        super().__init__()
        self.projector = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Linear(input_dim, output_dim)
        )

    def forward(self, x):
        if x.dim() == 3:
            x = x.mean(dim=1)
        return self.projector(x)