"""
EII-DAN 模型核心组件包
包含所有神经网络模块和组件
"""

from .core_components import (
    GradientReversalLayer,
    ContrastiveLoss,
    DynamicWeightScheduler
)

from .convolutional_encoder import (
    DynamicSeparableConv,
    MultiScaleTemporalPyramid,
    SpatioTemporalEncoder
)

from .attention_modules import HybridAttention

from .classifiers import (
    DomainClassifier,
    SubjectClassifier,
    ProjectionHead
)

from .eii_dan_model import EII_DAN

__all__ = [
    # 核心组件
    'GradientReversalLayer',
    'ContrastiveLoss',
    'DynamicWeightScheduler',

    # 卷积编码器
    'DynamicSeparableConv',
    'MultiScaleTemporalPyramid',
    'SpatioTemporalEncoder',

    # 注意力模块
    'HybridAttention',

    # 分类器
    'DomainClassifier',
    'SubjectClassifier',
    'ProjectionHead',

    # 主模型
    'EII_DAN'
]