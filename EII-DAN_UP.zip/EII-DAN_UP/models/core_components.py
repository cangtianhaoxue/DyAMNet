import torch
import torch.nn as nn
import torch.nn.functional as F

class GradientReversalLayer(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.alpha, None

class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.1, epsilon=1e-8):
        super().__init__()
        self.temperature = temperature
        self.epsilon = epsilon

    def forward(self, features, labels):
        batch_size = features.shape[0]

        if batch_size < 2:
            return torch.tensor(0.0, device=features.device)

        features = F.normalize(features, dim=1, eps=self.epsilon)
        similarity_matrix = torch.matmul(features, features.T) / self.temperature
        similarity_matrix = torch.clamp(similarity_matrix, -50, 50)

        labels = labels.unsqueeze(1)
        mask_positive = (torch.eq(labels, labels.T).float() -
                         torch.eye(batch_size, device=features.device))
        mask_negative = torch.ne(labels, labels.T).float()

        exp_sim = torch.exp(similarity_matrix)
        sum_neg = torch.sum(exp_sim * mask_negative, dim=1, keepdim=True) + self.epsilon

        pos_sim = torch.sum(similarity_matrix * mask_positive, dim=1)
        pos_count = torch.sum(mask_positive, dim=1) + self.epsilon
        pos_sim = pos_sim / pos_count

        loss = -pos_sim + torch.log(exp_sim.diag() + sum_neg.squeeze())

        if torch.isnan(loss).any() or torch.isinf(loss).any():
            return torch.tensor(0.0, device=features.device)

        return loss.mean()

class DynamicWeightScheduler:
    def __init__(self, lambda_0=1.0, min_lambda=0.1, max_lambda=2.0):
        self.lambda_0 = lambda_0
        self.min_lambda = min_lambda
        self.max_lambda = max_lambda

    def compute_weight(self, domain_accuracy):
        domain_accuracy = max(0.5, min(domain_accuracy, 1.0))
        lambda_t = self.lambda_0 * (2 * domain_accuracy - 1)
        return max(self.min_lambda, min(lambda_t, self.max_lambda))