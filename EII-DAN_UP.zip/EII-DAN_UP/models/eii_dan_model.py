import torch
import torch.nn as nn
from .convolutional_encoder import SpatioTemporalEncoder, EnhancedHybridAttention
from .classifiers import DomainClassifier, SubjectClassifier, ProjectionHead
from .core_components import GradientReversalLayer

class EII_DAN(nn.Module):
    def __init__(self, num_subjects, num_timesteps=128, spatial_dim=5,
                 num_channels=3, feature_dim=96, num_attention_heads=8, dropout=0.1):
        super().__init__()

        self.num_timesteps = num_timesteps
        self.spatial_dim = spatial_dim
        self.num_channels = num_channels
        self.feature_dim = feature_dim
        self.num_subjects = num_subjects

        self.encoder = SpatioTemporalEncoder(num_channels, feature_dim)

        actual_num_heads = min(num_attention_heads, feature_dim)
        if feature_dim % actual_num_heads != 0:
            for i in range(actual_num_heads, 0, -1):
                if feature_dim % i == 0:
                    actual_num_heads = i
                    break

        self.attention = EnhancedHybridAttention(feature_dim, actual_num_heads, dropout)
        self.subject_classifier = SubjectClassifier(feature_dim, num_subjects)
        self.domain_classifier = DomainClassifier(feature_dim)
        self.projector = ProjectionHead(feature_dim, feature_dim // 2)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, alpha=1.0, return_features=False):
        features = self.encoder(x)
        features = self.dropout(features)
        attended_features = self.attention(features)
        seq_representation = attended_features.mean(dim=1)
        subject_logits = self.subject_classifier(seq_representation)
        domain_features = GradientReversalLayer.apply(attended_features, alpha)
        domain_logits = self.domain_classifier(domain_features)
        contrastive_features = self.projector(seq_representation)

        if return_features:
            return subject_logits, domain_logits, contrastive_features, seq_representation

        return subject_logits, domain_logits, contrastive_features

    def get_parameter_count(self):
        return sum(p.numel() for p in self.parameters())