import torch
import sys
import os
import time
import argparse

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from experiments.demo_experiment4 import run_experiment4
from utils.check_environment import check_environment
from config.rtx4080_config import RTX4080Config

def main():
    parser = argparse.ArgumentParser(description='Run Experiment 4: Cross-Scenario Generalization')
    parser.add_argument('--scheme', type=int, choices=[1, 2, 3], default=1,
                       help='Data scheme: 1=50%, 2=20%, 3=10% source data')
    parser.add_argument('--run-all', action='store_true', 
                       help='Run all three schemes sequentially')
    
    args = parser.parse_args()
    
    check_environment()
    RTX4080Config.apply_optimizations()
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    if args.run_all:
        print("Running all three schemes for Experiment 4")
        all_results = {}
        
        for scheme in [1, 2, 3]:
            print(f"\n{'='*60}")
            print(f"Running Scheme {scheme}")
            print(f"{'='*60}")
            
            try:
                results = run_experiment4(scheme=scheme)
                all_results[scheme] = results
                
                print(f"\nScheme {scheme} completed successfully")
                
            except Exception as e:
                print(f"Scheme {scheme} failed: {e}")
                continue
        
        print(f"\n{'='*60}")
        print("Experiment 4 - All Schemes Summary")
        print(f"{'='*60}")
        
        for scheme, results in all_results.items():
            if 'accuracies' in results:
                target_accuracies = [acc for name, acc in results['accuracies'].items() 
                                   if name.startswith('target_')]
                if target_accuracies:
                    avg_target_acc = sum(target_accuracies) / len(target_accuracies)
                    print(f"Scheme {scheme}: Average Target Accuracy = {avg_target_acc:.2f}%")
        
    else:
        print(f"Running Experiment 4 with Scheme {args.scheme}")
        start_time = time.time()
        
        try:
            run_experiment4(scheme=args.scheme)
            end_time = time.time()
            print(f"Experiment 4 completed! Total time: {end_time - start_time:.2f} seconds")
            
        except Exception as e:
            print(f"Experiment 4 execution failed: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

if __name__ == "__main__":
    main()