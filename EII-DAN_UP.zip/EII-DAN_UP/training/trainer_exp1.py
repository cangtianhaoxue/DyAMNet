import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import time
import os
from typing import Dict, Any

class Exp1Trainer:
    def __init__(self, model, config, device=None):
        self.model = model.to(device)
        self.config = config
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.optimizer = optim.AdamW(
            model.parameters(),
            lr=config.base_learning_rate,
            weight_decay=config.weight_decay,
            betas=(0.9, 0.999)
        )

        self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.t_max,
            eta_min=config.min_learning_rate
        )

        self.subject_criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
        self.domain_criterion = nn.BCEWithLogitsLoss()

        self.train_history = {
            'epoch': [], 'train_loss': [], 'val_loss': [],
            'source_acc': [], 'target_acc': [], 'learning_rate': []
        }

        self.best_target_acc = 0.0
        self.best_model_state = None
        self.patience_counter = 0

    def _safe_data_normalization(self, data: torch.Tensor) -> torch.Tensor:
        eps = 1e-6
        if torch.isnan(data).any() or torch.isinf(data).any():
            data = torch.nan_to_num(data, nan=0.0, posinf=1.0, neginf=-1.0)

        batch_size = data.size(0)
        data_normalized = torch.zeros_like(data)

        for i in range(batch_size):
            sample = data[i]
            mean = sample.mean()
            std = sample.std()

            if std < eps:
                std = torch.tensor(eps, device=data.device)

            normalized_sample = (sample - mean) / std
            normalized_sample = torch.clamp(normalized_sample, -5.0, 5.0)
            normalized_sample = torch.nan_to_num(normalized_sample, nan=0.0)

            data_normalized[i] = normalized_sample

        return data_normalized

    def train_step(self, source_data, source_labels, target_data, target_labels,
                   source_domain, target_domain, domain_accuracy):
        
        self.optimizer.zero_grad()
        
        lambda_t = self.config.initial_lambda
        
        source_data = self._safe_data_normalization(source_data)
        target_data = self._safe_data_normalization(target_data)

        source_subject_logits, source_domain_logits, source_feat = self.model(source_data, alpha=lambda_t)
        _, target_domain_logits, target_feat = self.model(target_data, alpha=lambda_t)

        cls_loss = self.subject_criterion(source_subject_logits, source_labels)

        source_domain_loss = self.domain_criterion(source_domain_logits, source_domain)
        target_domain_loss = self.domain_criterion(target_domain_logits, target_domain)
        adv_loss = (source_domain_loss + target_domain_loss) / 2

        all_features = torch.cat([source_feat, target_feat], dim=0)
        all_labels = torch.cat([source_labels, target_labels], dim=0)
        
        features_norm = torch.nn.functional.normalize(all_features, p=2, dim=1, eps=1e-8)
        similarity_matrix = torch.matmul(features_norm, features_norm.T) / self.config.temperature
        similarity_matrix = torch.clamp(similarity_matrix, -10, 10)

        labels = all_labels.unsqueeze(1)
        mask_positive = (torch.eq(labels, labels.T).float() - torch.eye(len(labels), device=all_features.device))
        mask_negative = torch.ne(labels, labels.T).float()

        exp_sim = torch.exp(similarity_matrix) + 1e-10
        sum_positive = torch.sum(exp_sim * mask_positive, dim=1)
        sum_negative = torch.sum(exp_sim * mask_negative, dim=1) + 1e-10

        contrastive_loss = -torch.log(sum_positive / (sum_positive + sum_negative + 1e-8))
        contrastive_loss = contrastive_loss.mean()

        if torch.isnan(contrastive_loss).any() or torch.isinf(contrastive_loss).any():
            contrastive_loss = torch.tensor(0.0, device=self.device)

        total_loss = (cls_loss + 
                     self.config.initial_lambda * adv_loss + 
                     self.config.contrastive_loss_weight * contrastive_loss)

        total_loss.backward()

        if self.config.gradient_clipping > 0:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.gradient_clipping)

        self.optimizer.step()
        self.scheduler.step()

        return {
            'total_loss': total_loss.item(),
            'cls_loss': cls_loss.item(),
            'adv_loss': adv_loss.item(),
            'contrast_loss': contrastive_loss.item(),
            'lambda_t': lambda_t
        }

    def validate(self, data_loader):
        self.model.eval()
        total_correct = 0
        total_samples = 0

        with torch.no_grad():
            for batch in data_loader:
                data = batch['microstate_data'].to(self.device)
                labels = batch['subject_label'].to(self.device)

                data = self._safe_data_normalization(data)
                subject_logits, _, _ = self.model(data, alpha=0.0)
                predictions = torch.argmax(subject_logits, dim=1)

                total_correct += (predictions == labels).sum().item()
                total_samples += labels.size(0)

        accuracy = total_correct / total_samples * 100 if total_samples > 0 else 0
        self.model.train()
        return accuracy

    def train(self, dataloaders, num_epochs=None):
        num_epochs = num_epochs or self.config.training_epochs

        for epoch in range(num_epochs):
            train_metrics = self.train_epoch(dataloaders['source_train'], dataloaders['target_train'])
            val_metrics = self.validate(dataloaders['val']['target_val'])

            self.train_history['epoch'].append(epoch)
            self.train_history['train_loss'].append(train_metrics['total_loss'])
            self.train_history['target_acc'].append(val_metrics)

            if val_metrics > self.best_target_acc:
                self.best_target_acc = val_metrics
                self.best_model_state = self.model.state_dict()
                self.patience_counter = 0
            else:
                self.patience_counter += 1

            if self.patience_counter >= self.config.patience_epochs:
                break

        return {
            'best_accuracy': self.best_target_acc,
            'train_history': self.train_history
        }

    def train_epoch(self, source_loader, target_loader):
        self.model.train()
        epoch_loss = 0.0
        num_batches = 0

        for batch_idx, (source_batch, target_batch) in enumerate(zip(source_loader, target_loader)):
            source_data = source_batch['microstate_data'].to(self.device)
            source_labels = source_batch['subject_label'].to(self.device)
            target_data = target_batch['microstate_data'].to(self.device)
            target_labels = target_batch['subject_label'].to(self.device)

            source_domain = torch.ones(source_data.size(0), 1, device=self.device, dtype=torch.float32)
            target_domain = torch.zeros(target_data.size(0), 1, device=self.device, dtype=torch.float32)

            losses = self.train_step(
                source_data, source_labels, target_data, target_labels,
                source_domain, target_domain, 0.5
            )

            epoch_loss += losses['total_loss']
            num_batches += 1

        return {'total_loss': epoch_loss / num_batches if num_batches > 0 else 0.0}