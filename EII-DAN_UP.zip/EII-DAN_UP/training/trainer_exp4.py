import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
from typing import Dict, List, Optional

class Exp4Trainer:
    def __init__(self, model, device, config):
        self.model = model.to(device)
        self.device = device
        self.config = config
        
        self.ce_loss = nn.CrossEntropyLoss(label_smoothing=0.1)
        self.bce_loss = nn.BCEWithLogitsLoss()
        
        self.optimizer = optim.AdamW(
            model.parameters(),
            lr=config.base_learning_rate,
            weight_decay=config.weight_decay
        )
        
        self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.t_max,
            eta_min=config.min_learning_rate
        )
        
        self.scaler = torch.amp.GradScaler(device='cuda') if device.type == 'cuda' else None

    def compute_mmd_loss(self, source_features, target_features):
        if source_features.size(0) == 0 or target_features.size(0) == 0:
            return torch.tensor(0.0, device=self.device)
            
        source_mean = source_features.mean(0)
        target_mean = target_features.mean(0)
        
        mmd_loss = torch.norm(source_mean - target_mean, p=2)
        return mmd_loss

    def train_step_cross_scenario(self, source_data, source_labels, target_data, target_labels,
                                 source_domain, target_domain, current_epoch):
        
        self.optimizer.zero_grad()
        
        lambda_t = self.config.initial_lambda
        mmd_weight = self.config.mmd_loss_weight
        feature_align_weight = self.config.feature_alignment_lambda
        
        if self.scaler:
            with torch.amp.autocast(device_type='cuda'):
                losses = self._forward_pass_with_mmd(
                    source_data, source_labels, target_data, target_labels,
                    source_domain, target_domain, lambda_t, mmd_weight, feature_align_weight
                )
            
            self.scaler.scale(losses['total_loss']).backward()
            self.scaler.unscale_(self.optimizer)
            
            if self.config.gradient_clipping > 0:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.gradient_clipping)
                
            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            losses = self._forward_pass_with_mmd(
                source_data, source_labels, target_data, target_labels,
                source_domain, target_domain, lambda_t, mmd_weight, feature_align_weight
            )
            
            losses['total_loss'].backward()
            
            if self.config.gradient_clipping > 0:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.gradient_clipping)
                
            self.optimizer.step()
        
        self.scheduler.step()
        
        return {k: v.item() if torch.is_tensor(v) else v for k, v in losses.items()}

    def _forward_pass_with_mmd(self, source_data, source_labels, target_data, target_labels,
                              source_domain, target_domain, lambda_t, mmd_weight, feature_align_weight):
        
        source_outputs = self.model(source_data, alpha=lambda_t, return_features=True)
        target_outputs = self.model(target_data, alpha=lambda_t, return_features=True)
        
        if len(source_outputs) == 4:
            source_subject_logits, source_domain_logits, source_contrastive, source_features = source_outputs
            target_subject_logits, target_domain_logits, target_contrastive, target_features = target_outputs
        else:
            source_subject_logits, source_domain_logits, source_contrastive = source_outputs
            target_subject_logits, target_domain_logits, target_contrastive = target_outputs
            source_features = source_contrastive
            target_features = target_contrastive
        
        cls_loss = self.ce_loss(source_subject_logits, source_labels)
        
        source_domain_loss = self.bce_loss(source_domain_logits, source_domain)
        target_domain_loss = self.bce_loss(target_domain_logits, target_domain)
        adv_loss = (source_domain_loss + target_domain_loss) / 2
        
        all_features = torch.cat([source_contrastive, target_contrastive], dim=0)
        all_labels = torch.cat([source_labels, target_labels], dim=0)
        
        contrastive_loss = self._compute_contrastive_loss(all_features, all_labels)
        
        mmd_loss = self.compute_mmd_loss(source_features, target_features)
        
        feature_align_loss = torch.norm(source_features.mean(0) - target_features.mean(0), p=2)
        
        total_loss = (cls_loss + 
                     lambda_t * adv_loss + 
                     self.config.contrastive_loss_weight * contrastive_loss +
                     mmd_weight * mmd_loss +
                     feature_align_weight * feature_align_loss)
        
        return {
            'total_loss': total_loss,
            'cls_loss': cls_loss,
            'adv_loss': adv_loss,
            'contrast_loss': contrastive_loss,
            'mmd_loss': mmd_loss,
            'feature_align_loss': feature_align_loss,
            'lambda_t': lambda_t
        }

    def _compute_contrastive_loss(self, features, labels):
        features_norm = torch.nn.functional.normalize(features, p=2, dim=1, eps=1e-8)
        similarity_matrix = torch.matmul(features_norm, features_norm.T) / self.config.temperature
        similarity_matrix = torch.clamp(similarity_matrix, -10, 10)
        
        labels_expanded = labels.unsqueeze(1)
        mask_positive = (torch.eq(labels_expanded, labels_expanded.T).float() - 
                        torch.eye(len(labels), device=self.device))
        mask_negative = torch.ne(labels_expanded, labels_expanded.T).float()
        
        exp_sim = torch.exp(similarity_matrix) + 1e-10
        sum_positive = torch.sum(exp_sim * mask_positive, dim=1)
        sum_negative = torch.sum(exp_sim * mask_negative, dim=1) + 1e-10
        
        contrastive_loss = -torch.log(sum_positive / (sum_positive + sum_negative + 1e-8))
        contrastive_loss = contrastive_loss.mean()
        
        if torch.isnan(contrastive_loss).any() or torch.isinf(contrastive_loss).any():
            contrastive_loss = torch.tensor(0.0, device=self.device)
            
        return contrastive_loss

    def train_cross_scenario(self, dataloaders: Dict[str, DataLoader], num_epochs: Optional[int] = None):
        num_epochs = num_epochs or self.config.training_epochs
        
        source_loaders = [dataloaders[key] for key in dataloaders.keys() if key.startswith('source_')]
        target_loaders = [dataloaders[key] for key in dataloaders.keys() if key.startswith('target_')]
        
        training_history = []
        
        for epoch in range(num_epochs):
            epoch_losses = []
            
            for batch_idx in range(self.config.adversarial_training_steps):
                try:
                    source_loader = source_loaders[batch_idx % len(source_loaders)]
                    target_loader = target_loaders[batch_idx % len(target_loaders)]
                    
                    source_batch = next(iter(source_loader))
                    target_batch = next(iter(target_loader))
                    
                    source_data = source_batch['features'].to(self.device)
                    source_labels = source_batch['subject_id'].to(self.device)
                    target_data = target_batch['features'].to(self.device)
                    target_labels = target_batch['subject_id'].to(self.device)
                    
                    source_domain = torch.ones(source_data.size(0), 1, device=self.device, dtype=torch.float32)
                    target_domain = torch.zeros(target_data.size(0), 1, device=self.device, dtype=torch.float32)
                    
                    losses = self.train_step_cross_scenario(
                        source_data, source_labels, target_data, target_labels,
                        source_domain, target_domain, epoch
                    )
                    epoch_losses.append(losses)
                    
                except (StopIteration, IndexError):
                    continue
            
            if epoch_losses:
                avg_losses = {k: np.mean([loss[k] for loss in epoch_losses]) for k in epoch_losses[0].keys()}
                training_history.append(avg_losses)
                
                if epoch % 10 == 0:
                    print(f"Epoch {epoch}: Total Loss={avg_losses['total_loss']:.4f}, "
                          f"CLS={avg_losses['cls_loss']:.4f}, ADV={avg_losses['adv_loss']:.4f}, "
                          f"MMD={avg_losses['mmd_loss']:.4f}")
        
        return training_history

    def validate_cross_scenario(self, dataloaders: Dict[str, DataLoader]) -> Dict[str, float]:
        self.model.eval()
        accuracies = {}
        
        with torch.no_grad():
            for loader_name, loader in dataloaders.items():
                total_correct = 0
                total_samples = 0
                
                for batch in loader:
                    data = batch['features'].to(self.device)
                    labels = batch['subject_id'].to(self.device)
                    
                    subject_logits, _, _ = self.model(data, alpha=0.0)
                    predictions = torch.argmax(subject_logits, dim=1)
                    
                    total_correct += (predictions == labels).sum().item()
                    total_samples += labels.size(0)
                
                accuracy = total_correct / total_samples * 100 if total_samples > 0 else 0
                accuracies[loader_name] = accuracy
                
        self.model.train()
        return accuracies

    def get_current_lr(self):
        return self.optimizer.param_groups[0]['lr']