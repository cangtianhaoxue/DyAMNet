import torch
import torch.nn as nn
import torch.cuda.amp as amp
import math

class Exp2Trainer:
    def __init__(self, model, device, config):
        self.model = model.to(device)
        self.device = device
        self.config = config
        
        self.ce_loss = nn.CrossEntropyLoss(label_smoothing=0.1)
        self.bce_loss = nn.BCEWithLogitsLoss()
        
        self.optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config.base_learning_rate,
            weight_decay=config.weight_decay
        )
        
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.t_max,
            eta_min=config.min_learning_rate
        )
        
        self.scaler = torch.amp.GradScaler(device='cuda') if device.type == 'cuda' else None

    def train_step(self, source_data, source_labels, target_data, target_labels,
                   source_domain, target_domain, domain_accuracy):
        
        self.optimizer.zero_grad()
        
        lambda_t = self._compute_lambda_t(domain_accuracy)
        
        if self.scaler:
            with torch.amp.autocast(device_type='cuda'):
                losses = self._forward_pass(
                    source_data, source_labels, target_data, target_labels,
                    source_domain, target_domain, lambda_t
                )
            
            self.scaler.scale(losses['total_loss']).backward()
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            losses = self._forward_pass(
                source_data, source_labels, target_data, target_labels,
                source_domain, target_domain, lambda_t
            )
            
            losses['total_loss'].backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
        
        self.scheduler.step()
        
        return {k: v.item() if torch.is_tensor(v) else v for k, v in losses.items()}

    def _forward_pass(self, source_data, source_labels, target_data, target_labels,
                      source_domain, target_domain, lambda_t):
        
        source_subject_logits, source_domain_logits, _ = self.model(source_data, alpha=lambda_t)
        _, target_domain_logits, _ = self.model(target_data, alpha=lambda_t)
        
        cls_loss = self.ce_loss(source_subject_logits, source_labels)
        source_domain_loss = self.bce_loss(source_domain_logits, source_domain)
        target_domain_loss = self.bce_loss(target_domain_logits, target_domain)
        adv_loss = (source_domain_loss + target_domain_loss) / 2
        
        total_loss = cls_loss + lambda_t * adv_loss
        
        return {
            'total_loss': total_loss,
            'cls_loss': cls_loss,
            'adv_loss': adv_loss,
            'lambda_t': lambda_t
        }

    def _compute_lambda_t(self, domain_accuracy):
        if isinstance(domain_accuracy, torch.Tensor):
            domain_accuracy = domain_accuracy.item()
        
        lambda_t = self.config.initial_lambda / (
            1 + math.exp(-self.config.adjustment_rate * (0.5 - domain_accuracy))
        )
        return lambda_t

    def validate(self, data_loader):
        self.model.eval()
        total_correct = 0
        total_samples = 0
        
        with torch.no_grad():
            for batch in data_loader:
                data = batch['features'].to(self.device)
                labels = batch['subject'].to(self.device)
                
                subject_logits, _, _ = self.model(data)
                predictions = torch.argmax(subject_logits, dim=1)
                
                total_correct += (predictions == labels).sum().item()
                total_samples += labels.size(0)
        
        accuracy = total_correct / total_samples * 100 if total_samples > 0 else 0
        self.model.train()
        return accuracy

    def get_current_lr(self):
        return self.optimizer.param_groups[0]['lr']