import torch
import psutil
import time

class MemoryMonitor:
    def __init__(self):
        self.peak_gpu_memory = 0
        self.peak_ram_memory = 0
        self.start_time = None

    def start_monitoring(self):
        self.peak_gpu_memory = 0
        self.peak_ram_memory = 0
        self.start_time = time.time()

    def update(self):
        ram_usage = psutil.virtual_memory().used / 1024 ** 3

        if torch.cuda.is_available():
            gpu_usage = torch.cuda.memory_allocated() / 1024 ** 3
            self.peak_gpu_memory = max(self.peak_gpu_memory, gpu_usage)
        else:
            gpu_usage = 0

        self.peak_ram_memory = max(self.peak_ram_memory, ram_usage)

        return ram_usage, gpu_usage

    def get_summary(self):
        return {
            'peak_ram_gb': self.peak_ram_memory,
            'peak_gpu_gb': self.peak_gpu_memory,
            'monitoring_duration': time.time() - self.start_time if self.start_time else 0
        }

    def print_summary(self):
        print(f"Peak RAM usage: {self.peak_ram_memory:.2f} GB")
        if torch.cuda.is_available():
            print(f"Peak GPU usage: {self.peak_gpu_memory:.2f} GB")

    def clear_gpu_cache(self):
        if torch.cuda.is_available():
            torch.cuda.empty_cache()