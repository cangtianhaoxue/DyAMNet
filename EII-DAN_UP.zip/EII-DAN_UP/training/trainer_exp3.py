import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
from typing import Dict, List, Optional

class Exp3Trainer:
    def __init__(self, model, device, config):
        self.model = model.to(device)
        self.device = device
        self.config = config
        
        self.ce_loss = nn.CrossEntropyLoss(label_smoothing=0.1)
        self.bce_loss = nn.BCEWithLogitsLoss()
        
        self.optimizer = optim.AdamW(
            model.parameters(),
            lr=config.base_learning_rate,
            weight_decay=config.weight_decay
        )
        
        self.scheduler = optim.lr_scheduler.StepLR(
            self.optimizer,
            step_size=config.step_size,
            gamma=config.gamma
        )
        
        self.memory_buffer = []
        self.memory_buffer_size = config.memory_buffer_size
        
        self.current_domain = 0
        self.domain_accuracies = {}

    def compute_ewc_loss(self, model, fisher_dict, opt_params, lambda_ewc):
        if lambda_ewc == 0:
            return torch.tensor(0.0, device=self.device)
            
        ewc_loss = 0
        for name, param in model.named_parameters():
            if name in fisher_dict:
                fisher = fisher_dict[name]
                opt_param = opt_params[name]
                ewc_loss += (fisher * (param - opt_param).pow(2)).sum()
                
        return lambda_ewc * ewc_loss

    def update_memory_buffer(self, dataset, samples_per_subject=10):
        subject_samples = {}
        
        for i in range(len(dataset)):
            sample = dataset[i]
            subject_id = sample['subject_id']
            
            if subject_id not in subject_samples:
                subject_samples[subject_id] = []
                
            if len(subject_samples[subject_id]) < samples_per_subject:
                subject_samples[subject_id].append(sample)
                
        for subject_id, samples in subject_samples.items():
            self.memory_buffer.extend(samples)
            
        if len(self.memory_buffer) > self.memory_buffer_size:
            self.memory_buffer = self.memory_buffer[-self.memory_buffer_size:]

    def get_memory_loader(self, batch_size=32):
        if not self.memory_buffer:
            return None
            
        class MemoryDataset:
            def __init__(self, samples):
                self.samples = samples
                
            def __len__(self):
                return len(self.samples)
                
            def __getitem__(self, idx):
                return self.samples[idx]
                
        memory_dataset = MemoryDataset(self.memory_buffer)
        return DataLoader(memory_dataset, batch_size=batch_size, shuffle=True)

    def train_step_incremental(self, source_data, source_labels, target_data, target_labels,
                              source_domain, target_domain, memory_loader=None):
        
        self.optimizer.zero_grad()
        
        total_loss = 0
        losses_dict = {}
        
        source_subject_logits, source_domain_logits, source_feat = self.model(source_data, alpha=self.config.initial_lambda)
        target_subject_logits, target_domain_logits, target_feat = self.model(target_data, alpha=self.config.initial_lambda)
        
        cls_loss = self.ce_loss(source_subject_logits, source_labels)
        total_loss += cls_loss
        losses_dict['cls_loss'] = cls_loss.item()
        
        source_domain_loss = self.bce_loss(source_domain_logits, source_domain)
        target_domain_loss = self.bce_loss(target_domain_logits, target_domain)
        adv_loss = (source_domain_loss + target_domain_loss) / 2
        total_loss += self.config.initial_lambda * adv_loss
        losses_dict['adv_loss'] = adv_loss.item()
        
        all_features = torch.cat([source_feat, target_feat], dim=0)
        all_labels = torch.cat([source_labels, target_labels], dim=0)
        
        features_norm = torch.nn.functional.normalize(all_features, p=2, dim=1, eps=1e-8)
        similarity_matrix = torch.matmul(features_norm, features_norm.T) / self.config.temperature
        
        labels = all_labels.unsqueeze(1)
        mask_positive = (torch.eq(labels, labels.T).float() - torch.eye(len(labels), device=self.device))
        mask_negative = torch.ne(labels, labels.T).float()
        
        exp_sim = torch.exp(similarity_matrix) + 1e-10
        sum_positive = torch.sum(exp_sim * mask_positive, dim=1)
        sum_negative = torch.sum(exp_sim * mask_negative, dim=1) + 1e-10
        
        contrastive_loss = -torch.log(sum_positive / (sum_positive + sum_negative + 1e-8))
        contrastive_loss = contrastive_loss.mean()
        
        if torch.isnan(contrastive_loss).any() or torch.isinf(contrastive_loss).any():
            contrastive_loss = torch.tensor(0.0, device=self.device)
            
        total_loss += self.config.contrastive_loss_weight * contrastive_loss
        losses_dict['contrast_loss'] = contrastive_loss.item()
        
        if memory_loader:
            memory_loss = 0
            memory_batches = 0
            
            for memory_batch in memory_loader:
                if memory_batches >= 5:
                    break
                    
                memory_data = memory_batch['features'].to(self.device)
                memory_labels = memory_batch['subject_id'].to(self.device)
                
                memory_logits, _, _ = self.model(memory_data, alpha=0.0)
                memory_cls_loss = self.ce_loss(memory_logits, memory_labels)
                memory_loss += memory_cls_loss
                memory_batches += 1
                
            if memory_batches > 0:
                memory_loss = memory_loss / memory_batches
                total_loss += memory_loss
                losses_dict['memory_loss'] = memory_loss.item()
        
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        self.optimizer.step()
        self.scheduler.step()
        
        losses_dict['total_loss'] = total_loss.item()
        losses_dict['learning_rate'] = self.optimizer.param_groups[0]['lr']
        
        return losses_dict

    def validate_domain(self, data_loader):
        self.model.eval()
        total_correct = 0
        total_samples = 0
        
        with torch.no_grad():
            for batch in data_loader:
                data = batch['features'].to(self.device)
                labels = batch['subject_id'].to(self.device)
                
                subject_logits, _, _ = self.model(data, alpha=0.0)
                predictions = torch.argmax(subject_logits, dim=1)
                
                total_correct += (predictions == labels).sum().item()
                total_samples += labels.size(0)
                
        accuracy = total_correct / total_samples * 100 if total_samples > 0 else 0
        self.model.train()
        return accuracy

    def train_incremental_domains(self, dataloaders: Dict[str, DataLoader], num_subjects: int):
        domain_names = ['source'] + [f'target_{i}' for i in range(1, 8)]
        domain_results = {}
        
        for domain_idx, domain_name in enumerate(domain_names):
            if domain_name not in dataloaders:
                continue
                
            print(f"\n=== Training on {domain_name} ===")
            
            source_loader = dataloaders['source']
            target_loader = dataloaders[domain_name]
            
            if domain_idx > 0:
                memory_loader = self.get_memory_loader()
            else:
                memory_loader = None
            
            for epoch in range(self.config.training_epochs // 3):
                epoch_losses = []
                
                for batch_idx, (source_batch, target_batch) in enumerate(zip(source_loader, target_loader)):
                    if batch_idx >= min(30, len(source_loader)):
                        break
                        
                    source_data = source_batch['features'].to(self.device)
                    source_labels = source_batch['subject_id'].to(self.device)
                    target_data = target_batch['features'].to(self.device)
                    target_labels = target_batch['subject_id'].to(self.device)
                    
                    source_domain = torch.ones(source_data.size(0), 1, device=self.device, dtype=torch.float32)
                    target_domain = torch.zeros(target_data.size(0), 1, device=self.device, dtype=torch.float32)
                    
                    losses = self.train_step_incremental(
                        source_data, source_labels, target_data, target_labels,
                        source_domain, target_domain, memory_loader
                    )
                    epoch_losses.append(losses)
                
                if epoch_losses:
                    avg_loss = np.mean([loss['total_loss'] for loss in epoch_losses])
                    source_acc = self.validate_domain(source_loader)
                    target_acc = self.validate_domain(target_loader)
                    
                    if epoch % 5 == 0:
                        print(f"Epoch {epoch}: Loss={avg_loss:.4f}, Source Acc={source_acc:.2f}%, Target Acc={target_acc:.2f}%")
            
            domain_accuracy = self.validate_domain(target_loader)
            domain_results[domain_name] = domain_accuracy
            
            if domain_idx > 0:
                self.update_memory_buffer(target_loader.dataset)
                
            print(f"Domain {domain_name} completed with accuracy: {domain_accuracy:.2f}%")
        
        return domain_results

    def get_current_lr(self):
        return self.optimizer.param_groups[0]['lr']