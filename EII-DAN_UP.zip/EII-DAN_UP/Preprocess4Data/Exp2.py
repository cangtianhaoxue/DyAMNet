import os
import glob
import numpy as np
import shutil
import random
from collections import defaultdict
import json

class Exp3DataConfigurator:
    def __init__(self, exp3_root=r"D:\pythonProject\EII-DAN\Exp3"):
        self.exp3_root = exp3_root
        self.subjects_dir = os.path.join(exp3_root, "subjects")

    def organize_mat_files_by_subject(self):
        os.makedirs(self.subjects_dir, exist_ok=True)
        mat_pattern = os.path.join(self.exp3_root, "**", "*.mat")
        mat_files = glob.glob(mat_pattern, recursive=True)

        subject_files = defaultdict(list)

        for mat_file in mat_files:
            filename = os.path.basename(mat_file)
            subject_id = self.extract_subject_id(filename)
            if subject_id:
                subject_files[subject_id].append(mat_file)

        for subject_id, files in subject_files.items():
            subject_dir = os.path.join(self.subjects_dir, f"sub_{subject_id}")
            os.makedirs(subject_dir, exist_ok=True)

            for file_path in files:
                filename = os.path.basename(file_path)
                dest_path = os.path.join(subject_dir, filename)
                shutil.copy2(file_path, dest_path)

        return len(subject_files)

    def extract_subject_id(self, filename):
        parts = filename.split('_')

        for part in parts:
            if part.isdigit() and len(part) <= 3:
                return part

        if 'sub' in parts:
            sub_index = parts.index('sub')
            if sub_index + 1 < len(parts):
                return parts[sub_index + 1]

        return None

    def create_incremental_groups(self):
        subject_pattern = os.path.join(self.subjects_dir, "sub_*")
        subject_dirs = glob.glob(subject_pattern)

        subjects = []
        for dir_path in subject_dirs:
            dir_name = os.path.basename(dir_path)
            subject_id = dir_name.replace('sub_', '')
            subjects.append(subject_id)

        random.shuffle(subjects)
        groups = {}
        start_index = 0

        for group_num in range(1, 9):
            group_size = group_num

            if start_index + group_size <= len(subjects):
                group_subjects = subjects[start_index:start_index + group_size]
                start_index += group_size
            else:
                remaining = group_size - (len(subjects) - start_index)
                group_subjects = subjects[start_index:] + subjects[:remaining]
                start_index = remaining

            groups[group_num] = group_subjects

        return groups

    def create_data_configuration(self):
        subject_count = self.organize_mat_files_by_subject()
        groups = self.create_incremental_groups()

        config = {
            'experiment_name': 'Cross-user incremental domain adaptation',
            'total_subjects': subject_count,
            'source_domain': {
                'description': 'Initial 10 participants',
                'subjects': groups[1]
            },
            'target_domains': {},
            'incremental_groups': groups
        }

        for group_num in range(2, 9):
            config['target_domains'][f'stage_{group_num - 1}'] = {
                'description': f'Incremental stage {group_num - 1} - add {group_num} users',
                'subjects': groups[group_num]
            }

        config_path = os.path.join(self.exp3_root, "data_configuration.json")
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        self.generate_training_template(config)
        return config

    def generate_training_template(self, config):
        template = '''# Exp3 Incremental Domain Adaptation Training Script

import os
import numpy as np
import scipy.io as sio
from collections import defaultdict

class IncrementalDomainAdaptation:
    def __init__(self, config):
        self.config = config
        self.subjects_dir = r"{subjects_dir}"

    def load_subject_data(self, subject_id):
        subject_dir = os.path.join(self.subjects_dir, f"sub_{{subject_id}}")
        mat_files = glob.glob(os.path.join(subject_dir, "*.mat"))

        data = []
        labels = []

        for mat_file in mat_files:
            emotion_label = self.extract_emotion_label(os.path.basename(mat_file))
            mat_data = sio.loadmat(mat_file)
            feature_matrix = mat_data['feature_matrix']

            data.append(feature_matrix)
            labels.append(emotion_label)

        return np.array(data), np.array(labels)

    def extract_emotion_label(self, filename):
        parts = filename.split('_')
        if 'happy' in parts or '1' in parts:
            return 1
        elif 'sad' in parts or '0' in parts:
            return 0
        else:
            return -1

    def incremental_training(self):
        source_subjects = self.config['source_domain']['subjects']

        source_data = []
        source_labels = []

        for subject_id in source_subjects:
            data, labels = self.load_subject_data(subject_id)
            source_data.append(data)
            source_labels.append(labels)

        for stage_name, stage_config in self.config['target_domains'].items():
            target_subjects = stage_config['subjects']

            target_data = []
            target_labels = []

            for subject_id in target_subjects:
                data, labels = self.load_subject_data(subject_id)
                target_data.append(data)
                target_labels.append(labels)

if __name__ == "__main__":
    config = {config_json}
    trainer = IncrementalDomainAdaptation(config)
    trainer.incremental_training()
'''.format(
            subjects_dir=self.subjects_dir.replace('\\', '\\\\'),
            config_json=json.dumps(config, indent=2)
        )

        template_path = os.path.join(self.exp3_root, "incremental_training_template.py")
        with open(template_path, 'w', encoding='utf-8') as f:
            f.write(template)

    def validate_data_organization(self):
        if not os.path.exists(self.subjects_dir):
            return False

        subject_pattern = os.path.join(self.subjects_dir, "sub_*")
        subject_dirs = glob.glob(subject_pattern)

        file_stats = {}
        for subject_dir in subject_dirs:
            subject_id = os.path.basename(subject_dir).replace('sub_', '')
            mat_files = glob.glob(os.path.join(subject_dir, "*.mat"))
            file_stats[subject_id] = len(mat_files)

        return True

def main():
    configurator = Exp3DataConfigurator()
    config = configurator.create_data_configuration()
    configurator.validate_data_organization()

if __name__ == "__main__":
    main()