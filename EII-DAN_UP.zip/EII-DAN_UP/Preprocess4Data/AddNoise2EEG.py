import os
import numpy as np
import scipy.io as sio
from scipy import signal
import warnings

warnings.filterwarnings('ignore')


class EEGNoiseGenerator:
    def __init__(self, sampling_rate=128):
        self.sampling_rate = sampling_rate

    def generate_triangular_wave(self, n_points):
        half_point = n_points // 2
        rising = np.linspace(0, 1, half_point)
        falling = np.linspace(1, 0, n_points - half_point)
        return np.concatenate([rising, falling])

    def generate_eog_noise(self, eeg_data, snr_db=10):
        if eeg_data.ndim == 3:
            n_bands, n_channels, n_points = eeg_data.shape
            noisy_eeg = np.zeros_like(eeg_data)
            for band in range(n_bands):
                noisy_eeg[band] = self._generate_eog_noise_2d(eeg_data[band], snr_db)
            return noisy_eeg
        else:
            return self._generate_eog_noise_2d(eeg_data, snr_db)

    def _generate_eog_noise_2d(self, eeg_data, snr_db=10):
        n_channels, n_points = eeg_data.shape
        duration = np.random.uniform(0.2, 0.4)
        n_tri_points = int(duration * self.sampling_rate)
        tri_wave = self.generate_triangular_wave(n_tri_points)
        eog_noise = np.zeros(n_points)
        n_blinks = np.random.randint(2, 5)

        for _ in range(n_blinks):
            start_pos = np.random.randint(0, n_points - n_tri_points)
            end_pos = min(start_pos + n_tri_points, n_points)
            actual_length = end_pos - start_pos
            eog_noise[start_pos:end_pos] += tri_wave[:actual_length]

        signal_power = np.mean(eeg_data ** 2)
        noise_power = np.mean(eog_noise ** 2)

        if noise_power > 0:
            current_snr = 10 * np.log10(signal_power / noise_power)
            scale_factor = 10 ** ((current_snr - snr_db) / 20)
            eog_noise *= scale_factor

        noisy_eeg = eeg_data.copy()
        for ch in range(n_channels):
            channel_scale = 1.0 if ch == 0 else np.random.uniform(0.3, 0.8)
            noisy_eeg[ch] += eog_noise * channel_scale

        return noisy_eeg

    def generate_emg_noise(self, eeg_data, power_ratio=0.2):
        if eeg_data.ndim == 3:
            n_bands, n_channels, n_points = eeg_data.shape
            noisy_eeg = np.zeros_like(eeg_data)
            for band in range(n_bands):
                noisy_eeg[band] = self._generate_emg_noise_2d(eeg_data[band], power_ratio)
            return noisy_eeg
        else:
            return self._generate_emg_noise_2d(eeg_data, power_ratio)

    def _generate_emg_noise_2d(self, eeg_data, power_ratio=0.2):
        n_channels, n_points = eeg_data.shape
        white_noise = np.random.normal(0, 1, n_points)
        nyquist = self.sampling_rate / 2
        low_freq = 20
        high_freq = min(300, nyquist * 0.95)
        low = max(0.01, low_freq / nyquist)
        high = min(0.99, high_freq / nyquist)

        if low >= high:
            low = 0.1
            high = 0.5

        b, a = signal.butter(4, [low, high], btype='band')
        emg_noise = signal.filtfilt(b, a, white_noise)

        signal_power = np.mean(eeg_data ** 2)
        target_noise_power = signal_power * power_ratio
        current_noise_power = np.mean(emg_noise ** 2)

        if current_noise_power > 0:
            scale_factor = np.sqrt(target_noise_power / current_noise_power)
            emg_noise *= scale_factor

        noisy_eeg = eeg_data.copy()
        for ch in range(n_channels):
            channel_noise = emg_noise * np.random.uniform(0.8, 1.2)
            noisy_eeg[ch] += channel_noise

        return noisy_eeg

    def generate_impedance_drift(self, eeg_data, amplitude=100):
        if eeg_data.ndim == 3:
            n_bands, n_channels, n_points = eeg_data.shape
            noisy_eeg = np.zeros_like(eeg_data)
            for band in range(n_bands):
                noisy_eeg[band] = self._generate_impedance_drift_2d(eeg_data[band], amplitude)
            return noisy_eeg
        else:
            return self._generate_impedance_drift_2d(eeg_data, amplitude)

    def _generate_impedance_drift_2d(self, eeg_data, amplitude=100):
        n_channels, n_points = eeg_data.shape
        t = np.arange(n_points) / self.sampling_rate
        drift_freq = np.random.uniform(0.1, 2.0)
        phase_shift = np.random.uniform(0, 2 * np.pi)

        noisy_eeg = eeg_data.copy()
        for ch in range(n_channels):
            channel_amplitude = amplitude * np.random.uniform(0.5, 1.0)
            channel_drift = channel_amplitude * np.sin(2 * np.pi * drift_freq * t + phase_shift)
            noisy_eeg[ch] += channel_drift

        return noisy_eeg

    def generate_mixed_eog_emg(self, eeg_data, eog_snr=8, emg_power_ratio=0.3):
        if eeg_data.ndim == 3:
            n_bands, n_channels, n_points = eeg_data.shape
            noisy_eeg = np.zeros_like(eeg_data)
            for band in range(n_bands):
                noisy_eeg[band] = self._generate_mixed_eog_emg_2d(eeg_data[band], eog_snr, emg_power_ratio)
            return noisy_eeg
        else:
            return self._generate_mixed_eog_emg_2d(eeg_data, eog_snr, emg_power_ratio)

    def _generate_mixed_eog_emg_2d(self, eeg_data, eog_snr=8, emg_power_ratio=0.3):
        eog_noisy = self._generate_eog_noise_2d(eeg_data, eog_snr)
        emg_noisy = self._generate_emg_noise_2d(eeg_data, emg_power_ratio)
        mixed_noisy = eeg_data.copy()
        mixed_noisy += (eog_noisy - eeg_data)
        mixed_noisy += (emg_noisy - eeg_data)
        return mixed_noisy

    def generate_composite_mixed(self, eeg_data, eog_snr=10, emg_power_ratio=0.2, drift_amplitude=120):
        if eeg_data.ndim == 3:
            n_bands, n_channels, n_points = eeg_data.shape
            noisy_eeg = np.zeros_like(eeg_data)
            for band in range(n_bands):
                noisy_eeg[band] = self._generate_composite_mixed_2d(eeg_data[band], eog_snr, emg_power_ratio,
                                                                    drift_amplitude)
            return noisy_eeg
        else:
            return self._generate_composite_mixed_2d(eeg_data, eog_snr, emg_power_ratio, drift_amplitude)

    def _generate_composite_mixed_2d(self, eeg_data, eog_snr=10, emg_power_ratio=0.2, drift_amplitude=120):
        eog_noisy = self._generate_eog_noise_2d(eeg_data, eog_snr)
        emg_noisy = self._generate_emg_noise_2d(eeg_data, emg_power_ratio)
        drift_noisy = self._generate_impedance_drift_2d(eeg_data, drift_amplitude)
        composite_noisy = eeg_data.copy()
        composite_noisy += (eog_noisy - eeg_data)
        composite_noisy += (emg_noisy - eeg_data)
        composite_noisy += (drift_noisy - eeg_data)
        return composite_noisy


def process_deap_dataset():
    input_path = r"D:\pythonProject\EII-DAN\data\DEAP_processed"
    output_base_path = r"D:\pythonProject\EII-DAN\data\DEAP_processed_N"

    output_paths = {
        'N1': os.path.join(output_base_path, "N1_EOG"),
        'N2': os.path.join(output_base_path, "N2_EMG"),
        'N3': os.path.join(output_base_path, "N3_IDN"),
        'N4': os.path.join(output_base_path, "N4_EOG_EMG"),
        'N5': os.path.join(output_base_path, "N5_EOG_EMG_IDN")
    }

    for path in output_paths.values():
        os.makedirs(path, exist_ok=True)

    noise_generator = EEGNoiseGenerator(sampling_rate=128)
    mat_files = [f for f in os.listdir(input_path) if f.endswith('.mat')]

    print(f"Processing DEAP dataset: {len(mat_files)} files")

    processed_count = 0
    for i, mat_file in enumerate(mat_files):
        try:
            input_file_path = os.path.join(input_path, mat_file)
            data = sio.loadmat(input_file_path)

            if 'eeg_data' not in data:
                continue

            original_eeg = data['eeg_data']

            if original_eeg.ndim == 1:
                original_eeg = original_eeg.reshape(1, -1)
            elif original_eeg.ndim > 2:
                original_eeg = original_eeg.reshape(original_eeg.shape[0], -1)

            noisy_versions = {
                'N1': noise_generator.generate_eog_noise(original_eeg, snr_db=10),
                'N2': noise_generator.generate_emg_noise(original_eeg, power_ratio=0.2),
                'N3': noise_generator.generate_impedance_drift(original_eeg, amplitude=100),
                'N4': noise_generator.generate_mixed_eog_emg(original_eeg, eog_snr=8, emg_power_ratio=0.3),
                'N5': noise_generator.generate_composite_mixed(original_eeg, eog_snr=10, emg_power_ratio=0.2,
                                                               drift_amplitude=120)
            }

            for noise_type, noisy_data in noisy_versions.items():
                output_file = os.path.join(output_paths[noise_type], mat_file)
                output_data = data.copy()
                output_data['eeg_data'] = noisy_data
                output_data['noise_type'] = noise_type
                sio.savemat(output_file, output_data)

            processed_count += 1

        except Exception as e:
            continue

    print(f"DEAP completed: {processed_count}/{len(mat_files)} files")
    return processed_count


def process_seed_dataset():
    input_path = r"D:\pythonProject\EII-DAN\data\SEED_processed"
    output_base_path = r"D:\pythonProject\EII-DAN\data\SEED_processed_N"

    output_paths = {
        'N1': os.path.join(output_base_path, "N1_EOG"),
        'N2': os.path.join(output_base_path, "N2_EMG"),
        'N3': os.path.join(output_base_path, "N3_IDN"),
        'N4': os.path.join(output_base_path, "N4_EOG_EMG"),
        'N5': os.path.join(output_base_path, "N5_EOG_EMG_IDN")
    }

    for path in output_paths.values():
        os.makedirs(path, exist_ok=True)

    noise_generator = EEGNoiseGenerator(sampling_rate=200)
    mat_files = [f for f in os.listdir(input_path) if f.endswith('.mat')]

    print(f"Processing SEED dataset: {len(mat_files)} files")

    processed_count = 0
    for i, mat_file in enumerate(mat_files):
        try:
            input_file_path = os.path.join(input_path, mat_file)
            data = sio.loadmat(input_file_path)

            if 'data' not in data:
                continue

            original_eeg = data['data']

            if original_eeg.ndim == 1:
                original_eeg = original_eeg.reshape(1, -1)
            elif original_eeg.ndim > 2:
                original_eeg = original_eeg.reshape(original_eeg.shape[0], -1)

            noisy_versions = {
                'N1': noise_generator.generate_eog_noise(original_eeg, snr_db=10),
                'N2': noise_generator.generate_emg_noise(original_eeg, power_ratio=0.2),
                'N3': noise_generator.generate_impedance_drift(original_eeg, amplitude=100),
                'N4': noise_generator.generate_mixed_eog_emg(original_eeg, eog_snr=8, emg_power_ratio=0.3),
                'N5': noise_generator.generate_composite_mixed(original_eeg, eog_snr=10, emg_power_ratio=0.2,
                                                               drift_amplitude=120)
            }

            for noise_type, noisy_data in noisy_versions.items():
                output_file = os.path.join(output_paths[noise_type], mat_file)
                output_data = data.copy()
                output_data['data'] = noisy_data
                output_data['noise_type'] = noise_type
                sio.savemat(output_file, output_data)

            processed_count += 1

        except Exception as e:
            continue

    print(f"SEED completed: {processed_count}/{len(mat_files)} files")
    return processed_count


def process_thu_ep_dataset():
    input_path = r"D:\pythonProject\EII-DAN\data\THU-EP_processed"
    output_base_path = r"D:\pythonProject\EII-DAN\data\THU-EP_processed_N"

    output_paths = {
        'N1': os.path.join(output_base_path, "N1_EOG"),
        'N2': os.path.join(output_base_path, "N2_EMG"),
        'N3': os.path.join(output_base_path, "N3_IDN"),
        'N4': os.path.join(output_base_path, "N4_EOG_EMG"),
        'N5': os.path.join(output_base_path, "N5_EOG_EMG_IDN")
    }

    for path in output_paths.values():
        os.makedirs(path, exist_ok=True)

    noise_generator = EEGNoiseGenerator(sampling_rate=250)
    mat_files = [f for f in os.listdir(input_path) if f.endswith('.mat')]

    print(f"Processing THU-EP dataset: {len(mat_files)} files")

    processed_count = 0
    for i, mat_file in enumerate(mat_files):
        try:
            input_file_path = os.path.join(input_path, mat_file)
            data = sio.loadmat(input_file_path)

            if 'eeg_data' not in data:
                continue

            original_eeg = data['eeg_data']

            if original_eeg.ndim != 3:
                continue

            noisy_versions = {
                'N1': noise_generator.generate_eog_noise(original_eeg, snr_db=10),
                'N2': noise_generator.generate_emg_noise(original_eeg, power_ratio=0.2),
                'N3': noise_generator.generate_impedance_drift(original_eeg, amplitude=100),
                'N4': noise_generator.generate_mixed_eog_emg(original_eeg, eog_snr=8, emg_power_ratio=0.3),
                'N5': noise_generator.generate_composite_mixed(original_eeg, eog_snr=10, emg_power_ratio=0.2,
                                                               drift_amplitude=120)
            }

            for noise_type, noisy_data in noisy_versions.items():
                output_file = os.path.join(output_paths[noise_type], mat_file)
                output_data = data.copy()
                output_data['eeg_data'] = noisy_data
                output_data['noise_type'] = noise_type
                sio.savemat(output_file, output_data)

            processed_count += 1

        except Exception as e:
            continue

    print(f"THU-EP completed: {processed_count}/{len(mat_files)} files")
    return processed_count


def main():
    print("Starting dataset processing...")
    total_processed = 0

    if os.path.exists(r"D:\pythonProject\EII-DAN\data\DEAP_processed"):
        processed = process_deap_dataset()
        total_processed += processed

    if os.path.exists(r"D:\pythonProject\EII-DAN\data\SEED_processed"):
        processed = process_seed_dataset()
        total_processed += processed

    if os.path.exists(r"D:\pythonProject\EII-DAN\data\THU-EP_processed"):
        processed = process_thu_ep_dataset()
        total_processed += processed

    print(f"All datasets processed: {total_processed} total files")


if __name__ == "__main__":
    main()