import os
import glob
import numpy as np
import pandas as pd
from collections import defaultdict
import json

class MicrostateFeatureExtractor:
    def __init__(self, microstate_dir="microstate_results"):
        self.microstate_dir = microstate_dir
        self.dataset_sfreq = {
            'DEAP': 128,
            'SEED': 200,
            'THU_EP': 250
        }

    def detect_dataset_from_filename(self, filename):
        filename_lower = filename.lower()
        if 'deap' in filename_lower:
            return 'DEAP'
        elif 'seed' in filename_lower:
            return 'SEED'
        elif 'thu' in filename_lower or 'ep' in filename_lower:
            return 'THU_EP'
        else:
            if 'DEAP' in filename:
                return 'DEAP'
            elif 'SEED' in filename:
                return 'SEED'
            elif 'THU_EP' in filename:
                return 'THU_EP'
            else:
                return 'DEAP'

    def load_microstate_sequence(self, filepath):
        try:
            df = pd.read_csv(filepath)
            if 'microstate' in df.columns:
                return df['microstate'].values
            else:
                return df.iloc[:, 0].values
        except Exception as e:
            return None

    def calculate_transition_matrix(self, states, n_states=4):
        transition_counts = np.zeros((n_states, n_states), dtype=int)

        for i in range(len(states) - 1):
            current_state = states[i]
            next_state = states[i + 1]
            if current_state < n_states and next_state < n_states:
                transition_counts[current_state, next_state] += 1

        row_sums = transition_counts.sum(axis=1)
        transition_probs = np.zeros((n_states, n_states))

        for i in range(n_states):
            if row_sums[i] > 0:
                transition_probs[i, :] = transition_counts[i, :] / row_sums[i]

        return transition_probs

    def extract_non_diagonal_elements(self, matrix):
        n = matrix.shape[0]
        non_diag = []

        for i in range(n):
            for j in range(n):
                if i != j:
                    non_diag.append(matrix[i, j])

        return np.array(non_diag)

    def calculate_time_coverage(self, states, n_states=4):
        total_time = len(states)
        coverage = np.zeros(n_states)

        for state in range(n_states):
            coverage[state] = np.sum(states == state) / total_time

        return coverage

    def calculate_mean_duration(self, states, sfreq, n_states=4):
        durations = {state: [] for state in range(n_states)}
        current_state = states[0]
        current_duration = 1

        for i in range(1, len(states)):
            if states[i] == current_state:
                current_duration += 1
            else:
                if current_state < n_states:
                    durations[current_state].append(current_duration)
                current_state = states[i]
                current_duration = 1

        if current_state < n_states:
            durations[current_state].append(current_duration)

        mean_durations = np.zeros(n_states)
        for state in range(n_states):
            if durations[state]:
                mean_durations[state] = (np.mean(durations[state]) / sfreq) * 1000
            else:
                mean_durations[state] = 0

        return mean_durations

    def calculate_frequency(self, states, sfreq, n_states=4):
        total_time_seconds = len(states) / sfreq
        frequencies = np.zeros(n_states)

        for state in range(n_states):
            state_changes = np.diff(states == state, prepend=False)
            occurrence_count = np.sum(state_changes & (states == state))
            frequencies[state] = occurrence_count / total_time_seconds

        return frequencies

    def create_5x5_feature_matrix(self, features_24d):
        if len(features_24d) != 24:
            raise ValueError("Features must be 24-dimensional")

        matrix_5x5 = np.zeros((5, 5))

        idx = 0
        for i in range(5):
            for j in range(5):
                if idx < 24:
                    matrix_5x5[i, j] = features_24d[idx]
                    idx += 1
                else:
                    break

        return matrix_5x5

    def extract_features_for_file(self, filepath):
        states = self.load_microstate_sequence(filepath)
        if states is None:
            return None

        filename = os.path.basename(filepath)
        dataset = self.detect_dataset_from_filename(filename)
        sfreq = self.dataset_sfreq.get(dataset, 128)

        n_states = 4

        transition_matrix = self.calculate_transition_matrix(states, n_states)
        transition_features = self.extract_non_diagonal_elements(transition_matrix)

        coverage_features = self.calculate_time_coverage(states, n_states)

        duration_features = self.calculate_mean_duration(states, sfreq, n_states)

        frequency_features = self.calculate_frequency(states, sfreq, n_states)

        all_features = np.concatenate([
            transition_features,
            coverage_features,
            duration_features,
            frequency_features
        ])

        feature_matrix = self.create_5x5_feature_matrix(all_features)

        return {
            'filename': filename,
            'dataset': dataset,
            'sfreq': sfreq,
            'sequence_length': len(states),
            'features_24d': all_features,
            'feature_matrix_5x5': feature_matrix,
            'transition_matrix': transition_matrix,
            'coverage': coverage_features,
            'mean_duration': duration_features,
            'frequency': frequency_features
        }

    def process_all_files(self, output_dir="microstate_features"):
        os.makedirs(output_dir, exist_ok=True)

        pattern = os.path.join(self.microstate_dir, "**", "*_microstates.csv")
        microstate_files = glob.glob(pattern, recursive=True)

        all_results = {}
        summary_data = []

        for filepath in microstate_files:
            result = self.extract_features_for_file(filepath)
            if result is None:
                continue

            filename = result['filename']
            dataset = result['dataset']

            output_filename = f"{os.path.splitext(filename)[0]}_features.npz"
            output_path = os.path.join(output_dir, output_filename)

            np.savez(output_path,
                     features_24d=result['features_24d'],
                     feature_matrix_5x5=result['feature_matrix_5x5'],
                     transition_matrix=result['transition_matrix'],
                     coverage=result['coverage'],
                     mean_duration=result['mean_duration'],
                     frequency=result['frequency'])

            csv_filename = f"{os.path.splitext(filename)[0]}_feature_matrix.csv"
            csv_path = os.path.join(output_dir, csv_filename)
            pd.DataFrame(result['feature_matrix_5x5']).to_csv(csv_path, index=False, header=False)

            summary_data.append({
                'filename': filename,
                'dataset': dataset,
                'sequence_length': result['sequence_length'],
                'sfreq': result['sfreq'],
                'feature_file': output_filename,
                'csv_file': csv_filename
            })

            if dataset not in all_results:
                all_results[dataset] = []
            all_results[dataset].append(result)

        summary_df = pd.DataFrame(summary_data)
        summary_path = os.path.join(output_dir, "feature_extraction_summary.csv")
        summary_df.to_csv(summary_path, index=False)

        self._save_statistics(all_results, output_dir)

        return all_results

    def _save_statistics(self, all_results, output_dir):
        stats = {
            'total_files': 0,
            'datasets': {},
            'feature_shapes': {
                '24d_features': (24,),
                '5x5_matrix': (5, 5),
                'transition_matrix': (4, 4)
            }
        }

        for dataset, results in all_results.items():
            stats['datasets'][dataset] = len(results)
            stats['total_files'] += len(results)

            if results:
                all_features = np.array([r['features_24d'] for r in results])
                stats[f'{dataset}_mean_features'] = np.mean(all_features, axis=0).tolist()
                stats[f'{dataset}_std_features'] = np.std(all_features, axis=0).tolist()

        stats_path = os.path.join(output_dir, "extraction_statistics.json")
        with open(stats_path, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

    def load_features(self, feature_file):
        data = np.load(feature_file)
        return {
            'features_24d': data['features_24d'],
            'feature_matrix_5x5': data['feature_matrix_5x5'],
            'transition_matrix': data['transition_matrix'],
            'coverage': data['coverage'],
            'mean_duration': data['mean_duration'],
            'frequency': data['frequency']
        }

class FeatureAnalyzer:
    def __init__(self, feature_dir="microstate_features"):
        self.feature_dir = feature_dir

    def load_all_features(self):
        pattern = os.path.join(self.feature_dir, "*_features.npz")
        feature_files = glob.glob(pattern)

        all_features = []
        file_info = []

        for filepath in feature_files:
            try:
                data = np.load(filepath)
                all_features.append(data['features_24d'])
                file_info.append({
                    'filename': os.path.basename(filepath),
                    'feature_matrix': data['feature_matrix_5x5']
                })
            except Exception as e:
                continue

        return np.array(all_features), file_info

    def analyze_feature_distribution(self):
        features, file_info = self.load_all_features()

        if len(features) == 0:
            return None

        analysis = {
            'total_samples': len(features),
            'feature_dimension': features.shape[1],
            'mean_features': np.mean(features, axis=0).tolist(),
            'std_features': np.std(features, axis=0).tolist(),
            'min_features': np.min(features, axis=0).tolist(),
            'max_features': np.max(features, axis=0).tolist()
        }

        analysis_path = os.path.join(self.feature_dir, "feature_analysis.json")
        with open(analysis_path, 'w', encoding='utf-8') as f:
            json.dump(analysis, f, indent=2, ensure_ascii=False)

        return analysis

def main():
    microstate_dir = "../microstate_results"
    feature_dir = "../microstate_features"

    extractor = MicrostateFeatureExtractor(microstate_dir)
    results = extractor.process_all_files(feature_dir)

    analyzer = FeatureAnalyzer(feature_dir)
    analysis = analyzer.analyze_feature_distribution()

    print("Feature extraction completed")

if __name__ == "__main__":
    main()