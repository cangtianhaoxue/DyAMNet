
import torch
import sys
import os
import time
import argparse

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from experiments.demo_experiment2 import run_experiment2
from utils.check_environment import check_environment
from config.rtx4080_config import RTX4080Config


def main():
    parser = argparse.ArgumentParser(description='Run Experiment 2: Cross-session Subject Identification')
    parser.add_argument('--no-check', action='store_true', help='Skip environment check')
    parser.add_argument('--source-sessions', type=int, nargs='+', default=[1, 2],
                        help='Source domain sessions')
    parser.add_argument('--target-sessions', type=int, nargs='+', default=[3],
                        help='Target domain sessions')
    parser.add_argument('--epochs', type=int, default=100, help='Training epochs')
    args = parser.parse_args()

    print("Experiment 2: Cross-session Subject Identification")
    print(f"Source sessions: {args.source_sessions}")
    print(f"Target sessions: {args.target_sessions}")
    print(f"Epochs: {args.epochs}")

    if not args.no_check:
        check_environment()

    RTX4080Config.apply_optimizations()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")

    start_time = time.time()

    try:
        run_experiment2()

        end_time = time.time()
        print(f"Experiment 2 completed! Total time: {end_time - start_time:.2f}s")

    except Exception as e:
        print(f"Experiment 2 failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
