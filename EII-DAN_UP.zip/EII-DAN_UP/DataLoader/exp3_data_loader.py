import os
import glob
import numpy as np
import scipy.io as sio
import torch
from torch.utils.data import Dataset, DataLoader
import random
from typing import Dict, List, Tuple, Optional

class Exp3MicrostateDataset(Dataset):
    def __init__(self, file_paths: List[str], domain_label: int, sequence_length: int = 128):
        self.file_paths = file_paths
        self.domain_label = domain_label
        self.sequence_length = sequence_length
        self.samples = self._load_samples()

    def _load_samples(self):
        samples = []
        for file_path in self.file_paths:
            try:
                file_name = os.path.basename(file_path)
                file_info = self._parse_filename(file_name)
                
                samples.append({
                    'filepath': file_path,
                    'subject_id': file_info['subject_id'],
                    'movie_id': file_info['movie_id'],
                    'emotion_label': file_info['emotion_label'],
                    'domain': self.domain_label
                })
            except Exception as e:
                print(f"Error loading sample {file_path}: {e}")
                continue
        return samples

    def _parse_filename(self, filename: str) -> Dict:
        filename = filename.replace('.mat', '')
        parts = filename.split('_')
        
        info = {
            'dataset': parts[0],
            'subject_id': 0,
            'movie_id': 0,
            'emotion_label': 0
        }
        
        try:
            for i, part in enumerate(parts):
                if part == 'sub':
                    info['subject_id'] = int(parts[i + 1])
                elif part.isdigit() and len(part) == 1:
                    info['emotion_label'] = int(part)
                elif part.isdigit() and len(part) > 1:
                    info['movie_id'] = int(part)
        except:
            pass
            
        return info

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample_info = self.samples[idx]
        
        try:
            mat_data = sio.loadmat(sample_info['filepath'])
            feature_matrix = self._extract_feature_matrix(mat_data)
            
            if feature_matrix is None:
                feature_matrix = np.random.randn(3, 5, 5)
                
            feature_matrix = self._clean_and_normalize_data(feature_matrix)
            feature_matrix = self._ensure_proper_shape(feature_matrix)
            
            feature_tensor = torch.FloatTensor(feature_matrix)
            feature_tensor = feature_tensor.unsqueeze(0)
            feature_tensor = feature_tensor.repeat(self.sequence_length, 1, 1, 1)
            
            return {
                'features': feature_tensor,
                'subject_id': sample_info['subject_id'],
                'domain': sample_info['domain'],
                'movie_id': sample_info['movie_id'],
                'emotion_label': sample_info['emotion_label']
            }
            
        except Exception as e:
            print(f"Error loading file {sample_info['filepath']}: {e}")
            feature_tensor = torch.randn(self.sequence_length, 3, 5, 5)
            return {
                'features': feature_tensor,
                'subject_id': sample_info['subject_id'],
                'domain': sample_info['domain'],
                'movie_id': sample_info['movie_id'],
                'emotion_label': sample_info['emotion_label']
            }

    def _extract_feature_matrix(self, mat_data):
        for key in mat_data.keys():
            if 'microstate' in key.lower() or 'matrix' in key.lower():
                if isinstance(mat_data[key], np.ndarray) and mat_data[key].ndim >= 2:
                    return mat_data[key]
                    
        for key in mat_data.keys():
            if not key.startswith('__') and isinstance(mat_data[key], np.ndarray):
                if mat_data[key].ndim >= 2:
                    return mat_data[key]
        return None

    def _clean_and_normalize_data(self, matrix):
        if np.isnan(matrix).any() or np.isinf(matrix).any():
            matrix = np.nan_to_num(matrix, nan=0.0, posinf=1.0, neginf=-1.0)

        if np.std(matrix) > 0:
            matrix = (matrix - np.mean(matrix)) / (np.std(matrix) + 1e-8)
        else:
            matrix = (matrix - np.mean(matrix)) / 1e-8

        matrix = np.clip(matrix, -10, 10)
        return matrix

    def _ensure_proper_shape(self, matrix):
        if matrix is None:
            return np.random.randn(3, 5, 5)

        if matrix.ndim == 2:
            if matrix.shape[0] == 3 and matrix.shape[1] == 5:
                return matrix
            else:
                return self._reshape_to_3x5(matrix)
        elif matrix.ndim == 3:
            if matrix.shape[1] == 5 and matrix.shape[2] == 5:
                return matrix[0] if matrix.shape[0] == 3 else np.mean(matrix, axis=0)
            else:
                return self._reshape_to_3x5(matrix)
        else:
            return np.random.randn(3, 5, 5)

    def _reshape_to_3x5(self, matrix):
        matrix_flat = matrix.flatten()
        if len(matrix_flat) >= 15:
            return matrix_flat[:15].reshape(3, 5)
        else:
            padded = np.zeros(15)
            padded[:len(matrix_flat)] = matrix_flat
            return padded.reshape(3, 5)

class Exp3DataLoader:
    def __init__(self, base_dir: str = "D:/pythonProject/EII-DAN/Exp 3"):
        self.base_dir = base_dir
        self.subject_groups = self._organize_subject_groups()

    def _organize_subject_groups(self) -> Dict[int, List[str]]:
        subject_folders = []
        
        for item in os.listdir(self.base_dir):
            item_path = os.path.join(self.base_dir, item)
            if os.path.isdir(item_path) and item.startswith('sub_'):
                subject_folders.append(item)
        
        print(f"Found {len(subject_folders)} subject folders")
        
        random.shuffle(subject_folders)
        
        groups = {}
        start_idx = 0
        
        for group_size in range(1, 9):
            end_idx = start_idx + group_size
            if end_idx > len(subject_folders):
                break
                
            group_folders = subject_folders[start_idx:end_idx]
            groups[group_size] = group_folders
            start_idx = end_idx
            
            print(f"Group {group_size}: {len(group_folders)} subjects")
            
        return groups

    def _get_mat_files_from_subjects(self, subject_folders: List[str]) -> List[str]:
        all_mat_files = []
        
        for subject_folder in subject_folders:
            subject_path = os.path.join(self.base_dir, subject_folder)
            mat_files = glob.glob(os.path.join(subject_path, "*.mat"))
            
            for mat_file in mat_files:
                if "THU-EP" in mat_file and "microstates_matrix" in mat_file:
                    all_mat_files.append(mat_file)
                    
        return all_mat_files

    def load_all_domains(self) -> Dict[str, Tuple[Dataset, List[int]]]:
        domains = {}
        
        source_subjects = self.subject_groups[1]
        source_files = self._get_mat_files_from_subjects(source_subjects)
        source_dataset = Exp3MicrostateDataset(source_files, domain_label=0)
        source_subject_ids = self._extract_unique_subject_ids(source_files)
        
        domains['source'] = (source_dataset, source_subject_ids)
        print(f"Source domain: {len(source_files)} files, {len(source_subject_ids)} subjects")
        
        for group_size in range(2, 9):
            if group_size in self.subject_groups:
                target_subjects = self.subject_groups[group_size]
                target_files = self._get_mat_files_from_subjects(target_subjects)
                target_dataset = Exp3MicrostateDataset(target_files, domain_label=1)
                target_subject_ids = self._extract_unique_subject_ids(target_files)
                
                domain_name = f'target_{group_size-1}'
                domains[domain_name] = (target_dataset, target_subject_ids)
                print(f"Target domain {group_size-1}: {len(target_files)} files, {len(target_subject_ids)} subjects")
        
        return domains

    def _extract_unique_subject_ids(self, file_paths: List[str]) -> List[int]:
        subject_ids = set()
        
        for file_path in file_paths:
            file_name = os.path.basename(file_path)
            try:
                parts = file_name.replace('.mat', '').split('_')
                for i, part in enumerate(parts):
                    if part == 'sub':
                        subject_id = int(parts[i + 1])
                        subject_ids.add(subject_id)
                        break
            except:
                continue
                
        return sorted(list(subject_ids))

    def create_data_loaders(self, domains: Dict, batch_size: int = 32) -> Dict[str, DataLoader]:
        dataloaders = {}
        
        for domain_name, (dataset, _) in domains.items():
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=0,
                pin_memory=True
            )
            dataloaders[domain_name] = dataloader
            
        return dataloaders

    def get_all_subject_ids(self, domains: Dict) -> List[int]:
        all_subject_ids = set()
        
        for _, (_, subject_ids) in domains.items():
            all_subject_ids.update(subject_ids)
            
        return sorted(list(all_subject_ids))

    def remap_labels(self, datasets: Dict[str, Dataset], all_subject_ids: List[int]) -> Dict[str, Dataset]:
        subject_to_new_id = {old_id: new_id for new_id, old_id in enumerate(all_subject_ids)}
        
        remapped_datasets = {}
        
        for domain_name, dataset in datasets.items():
            for sample in dataset.samples:
                old_subject_id = sample['subject_id']
                if old_subject_id in subject_to_new_id:
                    sample['subject_id'] = subject_to_new_id[old_subject_id]
                    
            remapped_datasets[domain_name] = dataset
            
        return remapped_datasets