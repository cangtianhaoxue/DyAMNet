import os
import glob
import numpy as np
import scipy.io as sio
import torch
from torch.utils.data import Dataset, DataLoader
import random
from typing import Dict, List, Tuple, Optional

class Exp4MicrostateDataset(Dataset):
    def __init__(self, file_paths: List[str], domain_label: int, dataset_type: str, 
                 sequence_length: int = 128, is_source: bool = True):
        self.file_paths = file_paths
        self.domain_label = domain_label
        self.dataset_type = dataset_type
        self.sequence_length = sequence_length
        self.is_source = is_source
        self.samples = self._load_samples()

    def _load_samples(self):
        samples = []
        for file_path in self.file_paths:
            try:
                file_name = os.path.basename(file_path)
                file_info = self._parse_filename(file_name, self.dataset_type)
                
                if file_info['subject_id'] is not None:
                    samples.append({
                        'filepath': file_path,
                        'subject_id': file_info['subject_id'],
                        'session_id': file_info['session_id'],
                        'dataset': self.dataset_type,
                        'domain': self.domain_label,
                        'is_source': self.is_source
                    })
            except Exception as e:
                print(f"Error loading sample {file_path}: {e}")
                continue
        return samples

    def _parse_filename(self, filename: str, dataset_type: str) -> Dict:
        filename = filename.replace('.mat', '')
        parts = filename.split('_')
        
        info = {
            'subject_id': None,
            'session_id': 1,
            'emotion_label': 0
        }
        
        try:
            if dataset_type == "DEAP":
                for i, part in enumerate(parts):
                    if part == 'subj':
                        info['subject_id'] = int(parts[i + 1])
                    elif part.isdigit() and len(part) == 1:
                        info['emotion_label'] = int(part)
                        
            elif dataset_type == "THU-EP":
                for i, part in enumerate(parts):
                    if part == 'sub':
                        info['subject_id'] = int(parts[i + 1]) + 32
                    elif part.isdigit() and len(part) > 1:
                        if 1 <= int(part) <= 80:
                            info['subject_id'] = int(part) + 32
                            
            elif dataset_type == "SEED":
                for i, part in enumerate(parts):
                    if part.isdigit():
                        if len(part) == 1 or len(part) == 2:
                            if i > 0 and parts[i-1] in ['session', 'sess']:
                                info['session_id'] = int(part)
                            elif info['subject_id'] is None:
                                info['subject_id'] = int(part) + 112
                                
        except Exception as e:
            print(f"Error parsing filename {filename}: {e}")
            
        return info

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample_info = self.samples[idx]
        
        try:
            mat_data = sio.loadmat(sample_info['filepath'])
            feature_matrix = self._extract_feature_matrix(mat_data)
            
            if feature_matrix is None:
                feature_matrix = np.random.randn(3, 5, 5)
                
            feature_matrix = self._clean_and_normalize_data(feature_matrix)
            feature_matrix = self._ensure_proper_shape(feature_matrix)
            
            feature_tensor = torch.FloatTensor(feature_matrix)
            feature_tensor = feature_tensor.unsqueeze(0)
            feature_tensor = feature_tensor.repeat(self.sequence_length, 1, 1, 1)
            
            return {
                'features': feature_tensor,
                'subject_id': sample_info['subject_id'],
                'session_id': sample_info['session_id'],
                'dataset': sample_info['dataset'],
                'domain': sample_info['domain'],
                'is_source': sample_info['is_source']
            }
            
        except Exception as e:
            print(f"Error loading file {sample_info['filepath']}: {e}")
            feature_tensor = torch.randn(self.sequence_length, 3, 5, 5)
            return {
                'features': feature_tensor,
                'subject_id': sample_info['subject_id'],
                'session_id': sample_info['session_id'],
                'dataset': sample_info['dataset'],
                'domain': sample_info['domain'],
                'is_source': sample_info['is_source']
            }

    def _extract_feature_matrix(self, mat_data):
        for key in mat_data.keys():
            if 'microstate' in key.lower() or 'matrix' in key.lower():
                if isinstance(mat_data[key], np.ndarray) and mat_data[key].ndim >= 2:
                    return mat_data[key]
                    
        for key in mat_data.keys():
            if not key.startswith('__') and isinstance(mat_data[key], np.ndarray):
                if mat_data[key].ndim >= 2:
                    return mat_data[key]
        return None

    def _clean_and_normalize_data(self, matrix):
        if np.isnan(matrix).any() or np.isinf(matrix).any():
            matrix = np.nan_to_num(matrix, nan=0.0, posinf=1.0, neginf=-1.0)

        if np.std(matrix) > 0:
            matrix = (matrix - np.mean(matrix)) / (np.std(matrix) + 1e-8)
        else:
            matrix = (matrix - np.mean(matrix)) / 1e-8

        matrix = np.clip(matrix, -10, 10)
        return matrix

    def _ensure_proper_shape(self, matrix):
        if matrix is None:
            return np.random.randn(3, 5, 5)

        if matrix.ndim == 2:
            if matrix.shape[0] == 3 and matrix.shape[1] == 5:
                return matrix
            else:
                return self._reshape_to_3x5(matrix)
        elif matrix.ndim == 3:
            if matrix.shape[1] == 5 and matrix.shape[2] == 5:
                return matrix[0] if matrix.shape[0] == 3 else np.mean(matrix, axis=0)
            else:
                return self._reshape_to_3x5(matrix)
        else:
            return np.random.randn(3, 5, 5)

    def _reshape_to_3x5(self, matrix):
        matrix_flat = matrix.flatten()
        if len(matrix_flat) >= 15:
            return matrix_flat[:15].reshape(3, 5)
        else:
            padded = np.zeros(15)
            padded[:len(matrix_flat)] = matrix_flat
            return padded.reshape(3, 5)

class Exp4DataLoader:
    def __init__(self, base_dirs: Dict[str, str]):
        self.base_dirs = base_dirs
        self.subject_ranges = {
            'DEAP': (1, 32),
            'THU-EP': (33, 112),
            'SEED': (113, 127)
        }

    def _discover_dataset_files(self, dataset_name: str) -> List[str]:
        base_dir = self.base_dirs.get(dataset_name, "")
        if not base_dir or not os.path.exists(base_dir):
            print(f"Warning: Dataset {dataset_name} directory not found: {base_dir}")
            return []
            
        mat_files = []
        for root, dirs, files in os.walk(base_dir):
            for file in files:
                if file.endswith('.mat') and any(keyword in file for keyword in ['microstate', 'matrix', 'feature']):
                    mat_files.append(os.path.join(root, file))
                    
        print(f"Found {len(mat_files)} files for {dataset_name}")
        return mat_files

    def _filter_files_by_subjects(self, files: List[str], dataset_name: str, 
                                 subject_ids: List[int]) -> List[str]:
        filtered_files = []
        for file_path in files:
            file_name = os.path.basename(file_path)
            file_info = self._parse_file_info(file_name, dataset_name)
            
            if file_info['subject_id'] in subject_ids:
                filtered_files.append(file_path)
                
        return filtered_files

    def _parse_file_info(self, filename: str, dataset_name: str) -> Dict:
        filename = filename.replace('.mat', '')
        parts = filename.split('_')
        
        info = {
            'subject_id': None,
            'session_id': 1
        }
        
        try:
            if dataset_name == "DEAP":
                for i, part in enumerate(parts):
                    if part == 'subj':
                        info['subject_id'] = int(parts[i + 1])
                        
            elif dataset_name == "THU-EP":
                for i, part in enumerate(parts):
                    if part == 'sub':
                        info['subject_id'] = int(parts[i + 1]) + 32
                    elif part.isdigit() and len(part) > 1:
                        if 1 <= int(part) <= 80:
                            info['subject_id'] = int(part) + 32
                            
            elif dataset_name == "SEED":
                for i, part in enumerate(parts):
                    if part.isdigit():
                        if len(part) == 1 or len(part) == 2:
                            if i > 0 and parts[i-1] in ['session', 'sess']:
                                info['session_id'] = int(part)
                            elif info['subject_id'] is None:
                                info['subject_id'] = int(part) + 112
                                
        except:
            pass
            
        return info

    def create_scheme_1(self) -> Tuple[Dict[str, Dataset], Dict[str, Dataset]]:
        print("Creating Scheme 1: 50% THU-EP + 50% SEED in source")
        return self._create_data_scheme(thu_ep_ratio=0.5, seed_ratio=0.5, seed_sessions=[1, 2])

    def create_scheme_2(self) -> Tuple[Dict[str, Dataset], Dict[str, Dataset]]:
        print("Creating Scheme 2: 20% THU-EP + 20% SEED in source")
        return self._create_data_scheme(thu_ep_ratio=0.2, seed_ratio=0.2, seed_sessions=[1, 2])

    def create_scheme_3(self) -> Tuple[Dict[str, Dataset], Dict[str, Dataset]]:
        print("Creating Scheme 3: 10% THU-EP + 10% SEED in source")
        return self._create_data_scheme(thu_ep_ratio=0.1, seed_ratio=0.1, seed_sessions=[1])

    def _create_data_scheme(self, thu_ep_ratio: float, seed_ratio: float, 
                           seed_sessions: List[int]) -> Tuple[Dict[str, Dataset], Dict[str, Dataset]]:
        
        source_datasets = {}
        target_datasets = {}
        
        deap_files = self._discover_dataset_files('DEAP')
        thu_ep_files = self._discover_dataset_files('THU-EP')
        seed_files = self._discover_dataset_files('SEED')
        
        deap_subjects = list(range(1, 33))
        thu_ep_subjects = list(range(33, 113))
        seed_subjects = list(range(113, 128))
        
        random.shuffle(thu_ep_subjects)
        random.shuffle(seed_subjects)
        
        thu_ep_source_count = int(len(thu_ep_subjects) * thu_ep_ratio)
        seed_source_count = int(len(seed_subjects) * seed_ratio)
        
        thu_ep_source_subjects = thu_ep_subjects[:thu_ep_source_count]
        thu_ep_target_subjects = thu_ep_subjects[thu_ep_source_count:]
        
        seed_source_subjects = seed_subjects[:seed_source_count]
        seed_target_subjects = seed_subjects[seed_source_count:]
        
        print(f"DEAP: {len(deap_subjects)} subjects (100% source)")
        print(f"THU-EP: {len(thu_ep_source_subjects)} source, {len(thu_ep_target_subjects)} target")
        print(f"SEED: {len(seed_source_subjects)} source, {len(seed_target_subjects)} target")
        
        deap_source_files = self._filter_files_by_subjects(deap_files, 'DEAP', deap_subjects)
        thu_ep_source_files = self._filter_files_by_subjects(thu_ep_files, 'THU-EP', thu_ep_source_subjects)
        thu_ep_target_files = self._filter_files_by_subjects(thu_ep_files, 'THU-EP', thu_ep_target_subjects)
        
        seed_source_files = self._filter_seed_files_by_sessions(seed_files, seed_source_subjects, seed_sessions)
        seed_target_files = self._get_seed_target_files(seed_files, seed_source_subjects, seed_target_subjects)
        
        source_datasets['DEAP'] = Exp4MicrostateDataset(deap_source_files, 0, 'DEAP', is_source=True)
        source_datasets['THU-EP'] = Exp4MicrostateDataset(thu_ep_source_files, 0, 'THU-EP', is_source=True)
        source_datasets['SEED'] = Exp4MicrostateDataset(seed_source_files, 0, 'SEED', is_source=True)
        
        target_datasets['THU-EP'] = Exp4MicrostateDataset(thu_ep_target_files, 1, 'THU-EP', is_source=False)
        target_datasets['SEED'] = Exp4MicrostateDataset(seed_target_files, 1, 'SEED', is_source=False)
        
        return source_datasets, target_datasets

    def _filter_seed_files_by_sessions(self, seed_files: List[str], subject_ids: List[int], 
                                      sessions: List[int]) -> List[str]:
        filtered_files = []
        for file_path in seed_files:
            file_info = self._parse_file_info(os.path.basename(file_path), 'SEED')
            if file_info['subject_id'] in subject_ids and file_info['session_id'] in sessions:
                filtered_files.append(file_path)
        return filtered_files

    def _get_seed_target_files(self, seed_files: List[str], source_subjects: List[int], 
                              target_subjects: List[int]) -> List[str]:
        target_files = []
        
        for file_path in seed_files:
            file_info = self._parse_file_info(os.path.basename(file_path), 'SEED')
            
            if file_info['subject_id'] in source_subjects:
                if file_info['session_id'] == 3:
                    target_files.append(file_path)
            elif file_info['subject_id'] in target_subjects:
                target_files.append(file_path)
                
        return target_files

    def get_all_subject_ids(self, source_datasets: Dict[str, Dataset], 
                           target_datasets: Dict[str, Dataset]) -> List[int]:
        all_subject_ids = set()
        
        for dataset in source_datasets.values():
            for sample in dataset.samples:
                all_subject_ids.add(sample['subject_id'])
                
        for dataset in target_datasets.values():
            for sample in dataset.samples:
                all_subject_ids.add(sample['subject_id'])
                
        return sorted(list(all_subject_ids))

    def create_data_loaders(self, source_datasets: Dict[str, Dataset], 
                           target_datasets: Dict[str, Dataset], batch_size: int = 64) -> Dict[str, DataLoader]:
        
        dataloaders = {}
        
        for dataset_name, dataset in source_datasets.items():
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=0,
                pin_memory=True
            )
            dataloaders[f'source_{dataset_name}'] = dataloader
            
        for dataset_name, dataset in target_datasets.items():
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=False,
                num_workers=0,
                pin_memory=True
            )
            dataloaders[f'target_{dataset_name}'] = dataloader
            
        return dataloaders

    def remap_subject_ids(self, datasets: Dict[str, Dataset], all_subject_ids: List[int]) -> Dict[str, Dataset]:
        subject_to_new_id = {old_id: new_id for new_id, old_id in enumerate(all_subject_ids)}
        
        remapped_datasets = {}
        for name, dataset in datasets.items():
            for sample in dataset.samples:
                old_id = sample['subject_id']
                if old_id in subject_to_new_id:
                    sample['subject_id'] = subject_to_new_id[old_id]
            remapped_datasets[name] = dataset
            
        return remapped_datasets