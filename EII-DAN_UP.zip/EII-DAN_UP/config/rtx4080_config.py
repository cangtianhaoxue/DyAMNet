import torch

class RTX4080Config:
    @staticmethod
    def apply_optimizations():
        if torch.cuda.is_available():
            torch.backends.cudnn.benchmark = True
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True

            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()

    @staticmethod
    def get_optimal_batch_size(model_size="medium"):
        batch_sizes = {
            "small": 128,
            "medium": 64,
            "large": 32,
            "xlarge": 16
        }
        return batch_sizes.get(model_size, 64)