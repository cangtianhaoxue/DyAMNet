from dataclasses import dataclass
import torch

@dataclass
class BaseConfig:
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    num_workers: int = 4
    pin_memory: bool = True
    random_seed: int = 42
    
    optimizer: str = "AdamW"
    base_learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    training_epochs: int = 100
    batch_size: int = 64
    
    scheduler: str = "CosineAnnealingLR"
    t_max: int = 50
    min_learning_rate: float = 1e-6
    
    initial_lambda: float = 1.0
    adjustment_rate: float = 10
    grl_coefficient: float = -1
    
    temperature: float = 0.07
    positive_sample_pairs: str = "ID-matched cross-domain"
    negative_sample_pairs: str = "ID-mismatched"
    
    num_attention_heads: int = 4
    hidden_dimension: int = 96
    dropout_rate: float = 0.1
    
    patience_epochs: int = 15
    min_improvement: float = 1e-4
    
    sequence_length: int = 128
    frequency_bands: tuple = ("delta", "theta", "alpha")

@dataclass
class Experiment1Config(BaseConfig):
    def __init__(self):
        super().__init__()
        self.experiment_name = "Experiment1_NoiseRobustness"
        self.description = "噪声环境鲁棒性验证"
        
        self.batch_size = 64
        self.base_learning_rate = 8e-4
        self.data_augmentation_strength = 0.4
        self.contrastive_loss_weight = 1.2
        self.initial_lambda = 1.2
        self.dropout_rate = 0.15
        self.gradient_clipping = 1.2
        
        self.num_subjects = 10
        self.input_channels = 3
        self.feature_height = 5
        self.feature_width = 5
        self.feature_dim = 64
        self.num_heads = 2
        self.encoder_layers = 1
        
        self.lambda_domain = 0.1
        self.lambda_contrastive = 0.1
        self.lambda_mmd = 0.1
        self.temperature = 0.5
        
        self.use_data_augmentation = False
        self.augmentation_strength = 0.01
        self.patience = 20
        self.warmup_epochs = 5
        self.min_lr = 1e-9
        
        self.validation_ratio = 0.15
        self.test_ratio = 0.15
        self.model_save_dir = "./saved_models/exp1"
        self.results_save_dir = "./results/exp1"

@dataclass  
class Experiment2Config(BaseConfig):
    def __init__(self):
        super().__init__()
        self.experiment_name = "Experiment2_TemporalDrift"
        self.description = "时间漂移适应"
        
        self.batch_size = 48
        self.base_learning_rate = 5e-4
        self.sequence_length = 256
        self.initial_lambda = 0.8
        self.temperature = 0.05
        self.num_attention_heads = 8
        self.patience_epochs = 20

@dataclass
class Experiment3Config(BaseConfig):
    def __init__(self):
        super().__init__()
        self.experiment_name = "Experiment3_IncrementalUser"
        self.description = "增量用户扩展"
        
        self.batch_size = 32
        self.base_learning_rate = 3e-4
        self.contrastive_loss_weight = 1.5
        self.initial_lambda = 0.0
        self.memory_buffer_size = 2000
        self.ewc_weight = 0.3
        self.scheduler = "StepLR"
        self.step_size = 20
        self.gamma = 0.5

@dataclass
class Experiment4Config(BaseConfig):
    def __init__(self):
        super().__init__()
        self.experiment_name = "Experiment4_CrossScenario"
        self.description = "跨场景泛化"
        
        self.batch_size = 64
        self.base_learning_rate = 1e-3
        self.initial_lambda = 1.5
        self.mmd_loss_weight = 0.2
        self.temperature = 0.1
        self.adversarial_training_steps = 3
        self.feature_alignment_lambda = 0.4

@dataclass
class AblationConfig(BaseConfig):
    def __init__(self):
        super().__init__()
        self.experiment_name = "AblationStudy"
        self.description = "消融实验"
        
        self.batch_size = 64
        self.base_learning_rate = 1e-3
        self.training_epochs = 80
        self.patience_epochs = 10
        self.evaluation_protocol = "Protocol2"

EXP1_CONFIG = Experiment1Config()
EXP2_CONFIG = Experiment2Config()
EXP3_CONFIG = Experiment3Config()  
EXP4_CONFIG = Experiment4Config()
ABLATION_CONFIG = AblationConfig()

CONFIG_MAP = {
    "experiment1": EXP1_CONFIG,
    "experiment2": EXP2_CONFIG, 
    "experiment3": EXP3_CONFIG,
    "experiment4": EXP4_CONFIG,
    "ablation": ABLATION_CONFIG
}

def get_config(experiment_name):
    if experiment_name not in CONFIG_MAP:
        raise ValueError(f"Unknown experiment: {experiment_name}")
    return CONFIG_MAP[experiment_name]